# GREEN PLUG EV platform — Windows setup

Tested commands are for **Windows 10/11 + PowerShell**. Everything runs locally in demo mode: no paid services,
no real payments, nothing deployed.

## 1. Install the prerequisites

| Tool | Version | Notes |
|---|---|---|
| Node.js | **22 LTS** (22.x) | https://nodejs.org → Windows Installer (.msi). Includes npm. |
| PostgreSQL | **16** | EDB installer from https://www.postgresql.org/download/windows/. Keep the defaults: port **5432**, superuser **postgres**; remember the password you set. The `btree_gist` and `citext` extensions the app needs are included. Stack Builder is not needed. |
| A browser with WebGL | current Chrome / Edge / Firefox | for the real-time 3D scenes |

Check in a new PowerShell window:

```powershell
node -v          # v22.x
npm -v
& "C:\Program Files\PostgreSQL\16\bin\psql.exe" --version   # psql (PostgreSQL) 16.x
```

PostgreSQL runs as the Windows service **postgresql-x64-16** (Services app → Start, if it is stopped).

> If PowerShell says *running scripts is disabled* for `npm`, run once:
> `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` (or call `npm.cmd` instead of `npm`).

## 2. Unzip and install dependencies

Unzip to a short local path **outside OneDrive** (OneDrive syncing `node_modules` makes installs and builds very slow),
for example `C:\dev\green-plug-ev`. Keep the folder structure: `platform\` reuses the website's logo, theme, 3D parts
(`src\`) and the car model (`public\models\ev-concept.glb`).

```powershell
cd C:\dev\green-plug-ev\platform
npm install
```

This installs React, three.js, GSAP, the `postgres` driver, esbuild, TypeScript and Playwright into `platform\node_modules`.
(Running `npm install` in the repository root as well is optional — it is only needed for the marketing website. The
build always uses a single copy of React/three.js either way.)

## 3. Configure the environment

```powershell
Copy-Item .env.example .env
notepad .env
```

Change at least the database line to your PostgreSQL password and port:

```
DATABASE_URL=postgres://postgres:YOUR_PASSWORD@127.0.0.1:5432/gpev_dev
APP_ORIGIN=http://localhost:8080
```

If the password contains special characters (`@ : / # %`), URL-encode them (e.g. `@` → `%40`).
Leave the payment, maps and messaging variables empty — demo adapters are used and clearly labelled in the app.
`.env` stays on your computer; never commit it.

## 4. Build, create the database, start

```powershell
npm run build                                  # API + web app (+ copies the 3D car model) into dist\
node --env-file=.env dist/cli.mjs setup        # creates gpev_dev, runs migrations, loads demo data
node --env-file=.env dist/server.mjs           # → http://localhost:8080/app/
```

Open **http://localhost:8080/app/**. The cinematic intro plays on the first visit (Skip button or Esc; replay from
Profile). Stop the server with `Ctrl+C`.

Other database commands:

```powershell
node --env-file=.env dist/cli.mjs migrate      # apply new migrations only
node --env-file=.env dist/cli.mjs seed         # load demo data into an empty database
node --env-file=.env dist/cli.mjs reset        # DROP everything and recreate with fresh demo data
```

Development mode (rebuilds on save, restarts the API when server code changes):

```powershell
node --env-file=.env scripts/dev.mjs
```

Port 8080 busy? Set `PORT=8081` and `APP_ORIGIN=http://localhost:8081` in `.env`.

## 5. Demo accounts (local seed data only)

| Role | Email | Password |
|---|---|---|
| EV Driver (with a saved vehicle) | asha@greenplug.test | DriverDemo2026 |
| EV Driver | ravi@greenplug.test | DriverDemo2026 |
| Station Partner, approved (VizagVolt) | partner@greenplug.test | PartnerDemo2026 |
| Second approved partner (Coastal Charge) | coastal@greenplug.test | PartnerDemo2026 |
| Partner applicant, pending | applicant@greenplug.test | DriverDemo2026 |
| Administrator | admin@greenplug.test | AdminDemo2026 |

New sign-ups get their verification code in the in-app **Demo inbox** (no email is sent). Payments use the clearly
labelled **TEST checkout** — no real money.

## 6. Run the tests

Each suite resets its own database (`gpev_test`, `gpev_e2e`, `gpev_visual`) — never your `gpev_dev`. Point them at your
PostgreSQL (replace `YOUR_PASSWORD`):

```powershell
$pg = "postgres://postgres:YOUR_PASSWORD@127.0.0.1:5432"
$env:TEST_DATABASE_URL   = "$pg/gpev_test"
$env:E2E_DATABASE_URL    = "$pg/gpev_e2e"
$env:VISUAL_DATABASE_URL = "$pg/gpev_visual"

npm run typecheck          # strict TypeScript, server + web
npm test                   # 33 API tests

npx playwright install chromium   # once, downloads the test browser
npm run test:e2e           # 31-step browser workflow (driver → partner → admin)
npm run test:visual        # 3D/visual QA: screenshots + VISUAL-QA.md
```

Results and screenshots go to `tests\e2e\artifacts\` (`test:e2e` clears that folder, so run it before `test:visual`).
The suites start their own server on ports 8091–8093.

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| `ECONNREFUSED 127.0.0.1:5432` | Start the **postgresql-x64-16** service; check the port in `DATABASE_URL`. |
| `password authentication failed` | Wrong password in `.env` (URL-encode special characters). |
| `extension "btree_gist" is not available` | Use the EDB PostgreSQL 16 installer (it ships the contrib extensions). |
| `node: bad option: --env-file` | Node is older than 20.6 — install Node 22 LTS. |
| Page is blank / old | Re-run `npm run build`, then hard-refresh (Ctrl+F5). |
| No 3D, only illustrations | WebGL is unavailable, or Profile is set to "Lightweight illustrations" — switch to "Real-time 3D scenes". The app works fully without 3D. |
| Intro does not play again | It plays once per browser; use Profile → "Replay intro", or open `/app/?intro`. |

## Production

Not deployed. The server refuses `NODE_ENV=production` with demo settings — see `README.md` → *Production* and
`INTEGRATIONS.md` for the accounts and credentials a real deployment needs.
