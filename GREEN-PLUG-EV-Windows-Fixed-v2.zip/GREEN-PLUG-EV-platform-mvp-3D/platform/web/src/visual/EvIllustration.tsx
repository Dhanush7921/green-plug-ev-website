// Original SVG illustrations (three-quarter EV, charging pedestal, cable with an energy pulse). Used where WebGL is
// unavailable or not worth it (fallback for the 3D stage, vehicle cards, the mode-switch transition, empty states).
import { useId } from 'react';

export function EvIllustration({ charging = true, className = '', compact = false }: { charging?: boolean; className?: string; compact?: boolean }) {
  const id = useId().replace(/:/g, '');
  const g = (n: string) => `${n}-${id}`;
  return (
    <svg className={`ev-illus ${charging ? 'is-charging' : ''} ${className}`} viewBox={compact ? '40 70 590 260' : '0 40 640 320'} role="img" aria-label="Electric car connected to a GREEN PLUG EV charging station">
      <defs>
        <linearGradient id={g('body')} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--ill-paint-hi)" />
          <stop offset="0.55" stopColor="var(--ill-paint)" />
          <stop offset="1" stopColor="var(--ill-paint-lo)" />
        </linearGradient>
        <linearGradient id={g('glass')} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#2a4d45" />
          <stop offset="0.5" stopColor="#0b2b26" />
          <stop offset="1" stopColor="#051f20" />
        </linearGradient>
        <linearGradient id={g('pillar')} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="var(--ill-shell-lo)" />
          <stop offset="1" stopColor="var(--ill-shell)" />
        </linearGradient>
        <linearGradient id={g('screen')} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#163832" />
          <stop offset="1" stopColor="#051f20" />
        </linearGradient>
        <radialGradient id={g('shadow')}>
          <stop offset="0" stopColor="#051f20" stopOpacity="0.45" />
          <stop offset="1" stopColor="#051f20" stopOpacity="0" />
        </radialGradient>
        <radialGradient id={g('glow')}>
          <stop offset="0" stopColor="var(--ill-glow)" stopOpacity="0.9" />
          <stop offset="1" stopColor="var(--ill-glow)" stopOpacity="0" />
        </radialGradient>
        <linearGradient id={g('floor')} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="var(--ill-floor)" stopOpacity="0" />
          <stop offset="1" stopColor="var(--ill-floor)" stopOpacity="1" />
        </linearGradient>
      </defs>
      {!compact && (
        <g className="ill-floor">
          <path d="M0 250 L640 250 L640 360 L0 360Z" fill={`url(#${g('floor')})`} />
          <path d="M70 352 L170 252 M560 352 L520 252 M330 352 L340 252" stroke="var(--ill-line)" strokeWidth="3" opacity="0.5" />
        </g>
      )}
      <ellipse cx="300" cy="286" rx="250" ry="26" fill={`url(#${g('shadow')})`} />
      {/* charging pedestal */}
      <g className="ill-charger">
        <ellipse cx="572" cy="300" rx="56" ry="10" fill={`url(#${g('shadow')})`} />
        <path d="M594 104 L612 112 L612 296 L594 300Z" fill="var(--ill-shell-lo)" />
        <rect x="534" y="96" width="62" height="204" rx="14" fill={`url(#${g('pillar')})`} />
        <rect x="528" y="88" width="74" height="12" rx="6" fill="var(--ill-shell)" />
        <rect className="ill-cap" x="534" y="99" width="62" height="3" rx="1.5" fill="var(--ill-glow)" />
        <rect x="543" y="114" width="44" height="122" rx="8" fill="#0a1412" />
        <rect x="548" y="120" width="34" height="46" rx="4" fill={`url(#${g('screen')})`} />
        <rect className="ill-meter" x="553" y="150" width="24" height="5" rx="2.5" fill="var(--ill-glow)" />
        <path d="M556 133 a9 9 0 1 1 13 -2" fill="none" stroke="#daf1de" strokeWidth="3" strokeLinecap="round" />
        <rect className="ill-strip" x="589" y="122" width="3" height="100" rx="1.5" fill="var(--ill-glow)" />
        <rect x="528" y="150" width="10" height="20" rx="4" fill="#070b0a" />
      </g>
      {/* cable */}
      <path d="M531 160 C470 168 470 296 380 292 C320 290 300 236 268 196" fill="none" stroke="#0d1514" strokeWidth="7" strokeLinecap="round" />
      <path className="ill-energy" d="M531 160 C470 168 470 296 380 292 C320 290 300 236 268 196" fill="none" stroke="var(--ill-glow)" strokeWidth="3" strokeLinecap="round" />
      {/* car: wheels behind body edges */}
      <g className="ill-car">
        <path d="M86 214 L64 222 L66 252 L96 246Z" fill="var(--ill-paint-lo)" />
        <path d="M118 166 L80 182 L64 222 L104 206Z" fill="var(--ill-paint-hi)" />
        <path d="M150 254 L466 254 Q506 254 512 228 L516 192 Q514 172 492 166 L424 150 Q384 106 334 100 L232 100 Q194 102 170 128 L132 160 Q106 168 104 190 L102 226 Q104 252 150 254Z" fill={`url(#${g('body')})`} />
        <path d="M238 110 L328 110 Q362 114 392 148 L186 148 Q206 120 238 110Z" fill={`url(#${g('glass')})`} />
        <path d="M296 110 L300 148" stroke="var(--ill-paint)" strokeWidth="6" />
        <path d="M246 116 L282 116 L262 142 L214 142Z" fill="#ffffff" opacity="0.12" />
        <path d="M168 132 L134 160 L152 160 L186 132Z" fill={`url(#${g('glass')})`} opacity="0.9" />
        <path d="M124 196 Q300 182 500 196" stroke="#ffffff" strokeWidth="2" opacity="0.45" fill="none" />
        <path d="M70 226 L98 218" stroke="var(--ill-head)" strokeWidth="5" strokeLinecap="round" className="ill-head" />
        <path d="M108 176 L144 170" stroke="var(--ill-head)" strokeWidth="5" strokeLinecap="round" className="ill-head" />
        <path d="M486 176 L508 182" stroke="#c0392b" strokeWidth="5" strokeLinecap="round" opacity="0.8" />
        {[
          [196, 252, 34, 40],
          [418, 252, 34, 40],
        ].map(([cx, cy, rx, ry]) => (
          <g key={cx}>
            <ellipse cx={cx} cy={cy - 6} rx={rx + 8} ry={ry + 4} fill="var(--ill-paint-lo)" />
            <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="#0e1615" />
            <ellipse cx={cx + 2} cy={cy} rx={rx * 0.62} ry={ry * 0.66} fill="#c9d4ce" />
            <ellipse cx={cx + 2} cy={cy} rx={rx * 0.5} ry={ry * 0.54} fill="#8fa29a" />
            {[0, 72, 144, 216, 288].map((a) => (
              <line key={a} x1={cx + 2} y1={cy} x2={cx + 2 + Math.cos((a * Math.PI) / 180) * rx * 0.5} y2={cy + Math.sin((a * Math.PI) / 180) * ry * 0.54} stroke="#e6ece9" strokeWidth="4" />
            ))}
            <ellipse cx={cx + 2} cy={cy} rx="6" ry="7" fill="#163832" />
          </g>
        ))}
        <rect x="254" y="184" width="22" height="18" rx="5" fill="#111816" />
        <circle className="ill-port" cx="265" cy="193" r="5" fill="var(--ill-glow)" />
        <circle className="ill-port-glow" cx="265" cy="193" r="26" fill={`url(#${g('glow')})`} />
      </g>
    </svg>
  );
}

/** Compact vehicle glyph for vehicle cards (side three-quarter, no charger). */
export function EvGlyph({ className = '' }: { className?: string }) {
  return <EvIllustration compact charging={false} className={`ev-glyph ${className}`} />;
}
