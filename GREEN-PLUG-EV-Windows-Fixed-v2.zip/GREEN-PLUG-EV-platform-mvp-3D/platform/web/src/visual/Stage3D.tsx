// React host for the shared WebGL stage. Lazy-loads three.js, pauses when off-screen or hidden, follows the app
// theme, caps device-pixel-ratio by device class, and falls back to the SVG illustration without WebGL.
import { useEffect, useRef, useState } from 'react';
import { prefersReducedMotion } from '../../../../src/lib/prefs';
import { THEME_EVENT, currentTheme } from '../../../../src/lib/theme';
import type { EvStage, StageMode } from '../three/EvStage';
import { EvIllustration } from './EvIllustration';

export const MODEL_URL = '/app/models/ev-concept.glb';

export function deviceQuality(): 'high' | 'low' {
  const nav = navigator as Navigator & { deviceMemory?: number; connection?: { saveData?: boolean } };
  const small = window.innerWidth < 760;
  const weak = (nav.hardwareConcurrency || 4) <= 4 || (nav.deviceMemory ?? 8) <= 4;
  return small || weak || nav.connection?.saveData ? 'low' : 'high';
}
export function useModelAllowed() {
  const nav = navigator as Navigator & { connection?: { saveData?: boolean } };
  return !nav.connection?.saveData;
}

/** User setting (Profile → "3D scenes"): off uses the lightweight illustrations everywhere. */
export const THREE_D_KEY = 'gpev-3d';
export function threeDEnabled() {
  try {
    return localStorage.getItem(THREE_D_KEY) !== 'off';
  } catch {
    return true;
  }
}

let glOk: boolean | null = null;
export function hasWebGL() {
  if (glOk !== null) return glOk;
  try {
    const c = document.createElement('canvas');
    glOk = !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    glOk = false;
  }
  return glOk;
}

type Props = { mode: Exclude<StageMode, 'intro'>; className?: string; label: string; offsetX?: number; offsetY?: number };

export function Stage3D({ mode, className = '', label, offsetX = 0, offsetY = 0 }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<EvStage | null>(null);
  const [state, setState] = useState<'loading' | 'ready' | 'fallback'>(hasWebGL() && threeDEnabled() ? 'loading' : 'fallback');

  useEffect(() => {
    if (state === 'fallback') return;
    let disposed = false;
    let stage: EvStage | null = null;
    const el = host.current!;
    const reduced = prefersReducedMotion();
    const cleanups: (() => void)[] = [];
    (async () => {
      try {
        const { EvStage } = await import('../three/EvStage');
        if (disposed) return;
        stage = new EvStage({ canvas: canvas.current!, mode, theme: currentTheme(), quality: deviceQuality(), reducedMotion: reduced, modelUrl: MODEL_URL, useModel: useModelAllowed(), offsetX, offsetY });
        stageRef.current = stage;
        stage.onContextLost = () => setState('fallback');
        const r = el.getBoundingClientRect();
        stage.resize(r.width, r.height);
        await stage.init();
        if (disposed) return stage.dispose();
        (window as unknown as { __gpevStages?: Record<string, unknown> }).__gpevStages = { ...((window as unknown as { __gpevStages?: Record<string, unknown> }).__gpevStages || {}), [mode]: stage };
        const rr = el.getBoundingClientRect();
        stage.resize(rr.width, rr.height);
        if (reduced) stage.renderOnce();
        else stage.start();
        setState('ready');

        const ro = new ResizeObserver(([e]) => stage?.resize(e.contentRect.width, e.contentRect.height));
        ro.observe(el);
        cleanups.push(() => ro.disconnect());
        let visible = true;
        const io = new IntersectionObserver(([e]) => {
          visible = e.isIntersecting;
          stage?.setPaused(!visible || document.hidden);
        });
        io.observe(el);
        cleanups.push(() => io.disconnect());
        const onVis = () => stage?.setPaused(!visible || document.hidden);
        document.addEventListener('visibilitychange', onVis);
        cleanups.push(() => document.removeEventListener('visibilitychange', onVis));
        const onTheme = (e: Event) => stage?.setTheme((e as CustomEvent<'light' | 'dark'>).detail);
        window.addEventListener(THEME_EVENT, onTheme);
        cleanups.push(() => window.removeEventListener(THEME_EVENT, onTheme));
        if (!reduced) {
          const onMove = (e: PointerEvent) => {
            const b = el.getBoundingClientRect();
            stage?.setPointer(((e.clientX - b.left) / b.width) * 2 - 1, ((e.clientY - b.top) / b.height) * 2 - 1);
          };
          const onLeave = () => stage?.setPointer(0, 0);
          el.addEventListener('pointermove', onMove);
          el.addEventListener('pointerleave', onLeave);
          cleanups.push(() => (el.removeEventListener('pointermove', onMove), el.removeEventListener('pointerleave', onLeave)));
        }
      } catch (e) {
        console.warn('[GREEN PLUG EV] 3D stage unavailable, using the illustration.', e);
        if (!disposed) setState('fallback');
      }
    })();
    return () => {
      disposed = true;
      cleanups.forEach((f) => f());
      stage?.dispose();
      stageRef.current = null;
    };
    // the stage is rebuilt only when the mode changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, state === 'fallback']);

  useEffect(() => stageRef.current?.setOffset(offsetX, offsetY), [offsetX, offsetY]);

  return (
    <div ref={host} className={`stage3d stage3d-${mode} is-${state} ${className}`} role="img" aria-label={label} data-testid={`stage-${mode}`} data-stage-state={state}>
      {state !== 'ready' && <EvIllustration className="stage3d-fallback" />}
      {state !== 'fallback' && <canvas ref={canvas} aria-hidden="true" />}
      {state === 'ready' && (
        <span className="stage3d-tag" title="3D car: “Car Concept” © 2024 Darmstadt Graphics Group (artist Eric Chadwick), CC BY 4.0, modified. Chargers and scene are original.">
          Real-time 3D · illustrative scene · car model CC BY 4.0
        </span>
      )}
    </div>
  );
}
