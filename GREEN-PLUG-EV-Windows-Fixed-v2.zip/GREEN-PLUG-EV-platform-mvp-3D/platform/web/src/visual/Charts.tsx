// Small, dependency-free charts. Magnitudes use one hue (the brand accent); identity never relies on colour alone
// (every bar is directly labelled and has a hover tooltip). Tables with the same numbers sit next to each chart.
import { useState } from 'react';

export type Datum = { label: string; value: number; display: string; hint?: string };

/** Horizontal bars, sorted by the caller. Good for categories (status, accounts). */
export function BarList({ data, title, testId }: { data: Datum[]; title: string; testId?: string }) {
  const max = Math.max(1, ...data.map((d) => d.value));
  return (
    <figure className="barlist" data-testid={testId}>
      <figcaption className="chart-title">{title}</figcaption>
      <ul>
        {data.map((d, i) => (
          <li key={d.label} title={`${d.label}: ${d.display}${d.hint ? ` — ${d.hint}` : ''}`} style={{ ['--i' as string]: i }}>
            <span className="barlist-label">{d.label}</span>
            <span className="barlist-track">
              <span className="barlist-bar" style={{ transform: `scaleX(${d.value / max})` }} />
            </span>
            <span className="barlist-value">{d.display}</span>
          </li>
        ))}
      </ul>
      {!data.length && <p className="muted small">No data yet.</p>}
    </figure>
  );
}

/** Vertical columns with a hover tooltip; x labels are thinned automatically. */
export function Columns({ data, title, height = 180, testId }: { data: Datum[]; title: string; height?: number; testId?: string }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 600;
  const H = height;
  const pad = { l: 8, r: 8, t: 16, b: 26 };
  const max = Math.max(1, ...data.map((d) => d.value));
  const n = Math.max(1, data.length);
  const slot = (W - pad.l - pad.r) / n;
  const bw = Math.min(46, slot * 0.62);
  const every = Math.ceil(n / 8);
  const y = (v: number) => pad.t + (H - pad.t - pad.b) * (1 - v / max);
  return (
    <figure className="columns" data-testid={testId}>
      <figcaption className="chart-title">{title}</figcaption>
      <div className="columns-plot">
        <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="none" role="img" aria-label={`${title}: ${data.map((d) => `${d.label} ${d.display}`).join(', ')}`}>
          {[0.5, 1].map((f) => (
            <line key={f} className="chart-grid" x1={pad.l} x2={W - pad.r} y1={y(max * f)} y2={y(max * f)} />
          ))}
          <line className="chart-axis" x1={pad.l} x2={W - pad.r} y1={H - pad.b} y2={H - pad.b} />
          {data.map((d, i) => {
            const x = pad.l + slot * i + (slot - bw) / 2;
            const top = y(d.value);
            const h = Math.max(0, H - pad.b - top);
            return (
              <g key={i} onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)} onFocus={() => setHover(i)} onBlur={() => setHover(null)} tabIndex={0} aria-label={`${d.label}: ${d.display}`}>
                <rect x={pad.l + slot * i} y={pad.t} width={slot} height={H - pad.t - pad.b} fill="transparent" />
                <path className={`chart-col ${hover === i ? 'is-hover' : ''}`} style={{ ['--i' as string]: i }} d={h > 4 ? `M${x} ${H - pad.b} V${top + 4} Q${x} ${top} ${x + 4} ${top} H${x + bw - 4} Q${x + bw} ${top} ${x + bw} ${top + 4} V${H - pad.b}Z` : `M${x} ${H - pad.b - h} h${bw} v${h} h${-bw}Z`} />
                {i % every === 0 && (
                  <text className="chart-x" x={x + bw / 2} y={H - 8} textAnchor="middle">
                    {d.label}
                  </text>
                )}
              </g>
            );
          })}
        </svg>
        {hover !== null && data[hover] && (
          <div className="chart-tip" style={{ left: `${((pad.l + slot * hover + slot / 2) / W) * 100}%` }}>
            <strong>{data[hover].display}</strong>
            <span>{data[hover].label}</span>
            {data[hover].hint && <span className="muted">{data[hover].hint}</span>}
          </div>
        )}
      </div>
      {!data.length && <p className="muted small">No data yet.</p>}
    </figure>
  );
}

/** Two-part split shown as one bar with direct labels (part-to-whole of a single total). */
export function SplitBar({ parts, title, testId }: { parts: [Datum, Datum]; title: string; testId?: string }) {
  const total = Math.max(1, parts[0].value + parts[1].value);
  const a = (parts[0].value / total) * 100;
  return (
    <figure className="splitbar" data-testid={testId}>
      <figcaption className="chart-title">{title}</figcaption>
      <div className="splitbar-track" title={`${parts[0].label} ${parts[0].display} · ${parts[1].label} ${parts[1].display}`}>
        <span className="splitbar-a" style={{ width: `${a}%` }} />
        <span className="splitbar-b" style={{ width: `${100 - a}%` }} />
      </div>
      <div className="splitbar-legend">
        <span>
          <i className="sw sw-a" /> {parts[0].label} <strong>{parts[0].display}</strong> <em>{Math.round(a)}%</em>
        </span>
        <span>
          <i className="sw sw-b" /> {parts[1].label} <strong>{parts[1].display}</strong> <em>{Math.round(100 - a)}%</em>
        </span>
      </div>
    </figure>
  );
}
