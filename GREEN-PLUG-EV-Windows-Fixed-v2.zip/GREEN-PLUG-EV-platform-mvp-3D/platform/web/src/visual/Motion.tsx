// Motion-system building blocks: skeletons, availability indicators, the energy meter, the route-progress strip and
// the SWITCH MODE transition layer. CSS does the animating (transform/opacity only); reduced motion turns it off.
import { useEffect, useState } from 'react';
import { prefersReducedMotion } from '../../../../src/lib/prefs';
import { Icon } from '../components/Icon';

export function Skeleton({ rows = 3, kind = 'card' }: { rows?: number; kind?: 'card' | 'row' | 'stat' }) {
  return (
    <div className={`skeleton-list sk-${kind}`} aria-busy="true" aria-label="Loading">
      {Array.from({ length: rows }, (_, i) => (
        <div key={i} className="skeleton" style={{ ['--i' as string]: i }}>
          <span className="sk-line w60" />
          <span className="sk-line w40" />
          {kind === 'card' && <span className="sk-line w80" />}
        </div>
      ))}
    </div>
  );
}

export type Avail = 'available' | 'busy' | 'unavailable';
export function AvailDot({ state, label }: { state: Avail; label?: string }) {
  return (
    <span className={`avail avail-${state}`}>
      <span className="avail-dot" aria-hidden="true" />
      {label}
    </span>
  );
}

/** Battery-style meter for a planned session: energy, estimated time, animated flow while charging. */
export function EnergyMeter({ kwh, maxKwh, minutes, charging = true, label }: { kwh: number; maxKwh: number; minutes?: string; charging?: boolean; label?: string }) {
  const f = Math.max(0.04, Math.min(1, kwh / Math.max(1, maxKwh)));
  return (
    <div className={`energy-meter ${charging ? 'is-flowing' : ''}`} data-testid="energy-meter">
      <div className="em-cell" aria-hidden="true">
        <span className="em-fill" style={{ transform: `scaleX(${f})` }} />
        <span className="em-flow" />
        <span className="em-cap" />
      </div>
      <div className="em-text">
        <Icon name="battery-charging" />
        <strong>{kwh} kWh</strong>
        {minutes && <span className="muted">· {minutes}</span>}
        {label && <span className="muted">· {label}</span>}
      </div>
    </div>
  );
}

/** Animated trip strip: start → charging stops → destination, with the EV travelling along it. */
export function RouteProgress({ distanceKm, stops, start, end, rangeKm }: { distanceKm: number; stops: { name: string; kmFromStart: number }[]; start: string; end: string; rangeKm: number }) {
  const pct = (km: number) => Math.max(0, Math.min(100, (km / Math.max(1, distanceKm)) * 100));
  return (
    <div className="route-progress" data-testid="route-progress">
      <div className="rp-track">
        <span className="rp-line" />
        <span className="rp-energy" />
        <span className="rp-car" aria-hidden="true">
          <Icon name="car" />
        </span>
        <span className="rp-node rp-start" style={{ left: '0%' }}>
          <i />
          <span className="rp-label">{start}</span>
        </span>
        {stops.map((s, i) => (
          <span key={s.name} className="rp-node rp-stop" style={{ left: `${pct(s.kmFromStart)}%`, ['--i' as string]: i }}>
            <i>
              <Icon name="zap" />
            </i>
            <span className="rp-label">
              Stop {i + 1} · {s.kmFromStart} km
            </span>
          </span>
        ))}
        <span className="rp-node rp-end" style={{ left: '100%' }}>
          <i />
          <span className="rp-label">{end}</span>
        </span>
      </div>
      <p className="muted small">
        {distanceKm} km · usable range {rangeKm} km per charge · {stops.length} charging stop{stops.length === 1 ? '' : 's'}
      </p>
    </div>
  );
}

/** Short layered "energy sweep" played on top of the app while SWITCH MODE navigates (never blocks input). */
export const MODE_EVENT = 'gpev:mode-transition';
export function ModeTransition() {
  const [run, setRun] = useState<{ id: number; to: string } | null>(null);
  useEffect(() => {
    const on = (e: Event) => {
      if (prefersReducedMotion()) return;
      const to = (e as CustomEvent<string>).detail;
      const id = Date.now();
      setRun({ id, to });
      window.setTimeout(() => setRun((r) => (r && r.id === id ? null : r)), 12000); // safety net; normally ends on animationend
    };
    window.addEventListener(MODE_EVENT, on);
    return () => window.removeEventListener(MODE_EVENT, on);
  }, []);
  if (!run) return null;
  return (
    <div key={run.id} className={`mode-transition to-${run.to}`} aria-hidden="true" data-testid="mode-transition">
      <span className="mt-panel mt-1" />
      <span className="mt-panel mt-2" />
      <span className="mt-line" />
      <span className="mt-ev" onAnimationEnd={() => setRun(null)}>
        <Icon name={run.to === 'partner' ? 'plug-zap' : run.to === 'admin' ? 'shield' : 'car'} />
      </span>
    </div>
  );
}

/** Adds .is-in to [data-reveal] elements as they scroll into view (staggered with --i). */
export function useRevealRoot(key: unknown) {
  useEffect(() => {
    const root = document.getElementById('main');
    if (!root) return;
    if (prefersReducedMotion() || !('IntersectionObserver' in window)) {
      root.querySelectorAll('[data-reveal]').forEach((el) => el.classList.add('is-in'));
      return;
    }
    const io = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('is-in');
            io.unobserve(e.target);
          }
        }),
      { rootMargin: '0px 0px -6% 0px' },
    );
    const scan = () => root.querySelectorAll('[data-reveal]:not(.is-in)').forEach((el) => io.observe(el));
    scan();
    const mo = new MutationObserver(scan);
    mo.observe(root, { childList: true, subtree: true });
    return () => (io.disconnect(), mo.disconnect());
  }, [key]);
}
