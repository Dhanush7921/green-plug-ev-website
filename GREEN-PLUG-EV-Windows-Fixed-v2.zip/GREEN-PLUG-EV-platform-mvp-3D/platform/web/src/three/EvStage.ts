// GREEN PLUG EV — shared real-time 3D stage for the app (three.js / WebGL).
//
// One scene, several camera presets: the cinematic startup intro (drive-in → plug-in → energy → reveal), the
// driver home hero, the station-detail close-up and the partner / admin headers. It reuses the website's original
// procedural models (charger, CCS2 connector + inlet, Verlet cable) and the licensed concept car (CC BY 4.0, see
// ASSETS.md), and adds its own charging-bay environment, glow sprites (a restrained, cheap stand-in for bloom),
// energy orbs that ride the simulated cable, drifting particles and a station light response.
//
// Performance: one render loop per stage, paused off-screen or when the page is hidden, DPR capped per quality,
// adaptive resolution, reflections only in the high-quality intro, everything disposed on unmount.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { Reflector } from 'three/examples/jsm/objects/Reflector.js';
import { gsap } from 'gsap';
import { Cable } from '../../../../src/three/cable';
import { loadCar, proceduralCar, type CarRig } from '../../../../src/three/car';
import { createCharger, drawMark } from '../../../../src/three/charger';
import { COLLAR_DEPTH, createConnector, createConnectorMaterials } from '../../../../src/three/connector';
import { PALETTE, SCENE_THEMES } from '../../../../src/three/palette';

export type StageMode = 'intro' | 'hero' | 'station' | 'partner' | 'admin';
export type StageTheme = 'light' | 'dark';
export type StageQuality = 'high' | 'low';
export type StageOptions = {
  canvas: HTMLCanvasElement;
  mode: StageMode;
  theme: StageTheme;
  quality: StageQuality;
  reducedMotion: boolean;
  modelUrl: string;
  useModel: boolean;
  /** horizontal composition: negative shifts the scene right (room for copy on the left) */
  offsetX?: number;
  offsetY?: number;
};
export type IntroCue = 'arrive' | 'plug' | 'charge' | 'reveal' | 'exit' | 'done';

THREE.Cache.enabled = true; // the car model is fetched once per page load and parsed from memory afterwards

const v3 = (x: number, y: number, z: number) => new THREE.Vector3(x, y, z);
const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
const smooth = (a: number, b: number, x: number) => {
  const t = clamp01((x - a) / (b - a));
  return t * t * (3 - 2 * t);
};

const CHARGER_POS = v3(2.15, 0, -0.35);
const CHARGER_ROT = Math.PI / 4;
const CHARGER2_POS = v3(-2.35, 0, -0.55);
const CHARGER2_ROT = -Math.PI / 4;

type CamPose = { pos: THREE.Vector3; tgt: THREE.Vector3; fov: number };
type Look = {
  bgTop: string;
  bgBottom: string;
  fog: string;
  floor: string;
  line: string;
  wall: string;
  fin: string;
  city: string;
  window: string;
  hedge: string;
  glow: string;
  particles: string;
  particleOpacity: number;
  shadow: number;
};
const LOOKS: Record<StageTheme, Look> = {
  light: {
    // mid-tone sage surroundings so the pale car and chargers read with depth instead of white-on-white
    bgTop: '#e2eee6',
    bgBottom: '#a8c6b4',
    fog: '#cadcd0',
    floor: '#b3cebe',
    line: '#f4fbf6',
    wall: '#bdd4c6',
    fin: PALETTE.sage,
    city: '#9cbdaa',
    window: '#ffffff',
    hedge: PALETTE.moss,
    glow: PALETTE.moss,
    particles: PALETTE.moss,
    particleOpacity: 0.35,
    shadow: 0.62,
  },
  dark: {
    bgTop: '#0b2b26',
    bgBottom: '#031415',
    fog: '#06201f',
    floor: '#0a2220',
    line: PALETTE.sage,
    wall: '#0f2c28',
    fin: PALETTE.mint,
    city: '#0c2824',
    window: PALETTE.mint,
    hedge: PALETTE.spruce,
    glow: PALETTE.sage,
    particles: PALETTE.mint,
    particleOpacity: 0.55,
    shadow: 0.8,
  },
};

function canvasTex(w: number, h: number, draw: (g: CanvasRenderingContext2D) => void) {
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  draw(c.getContext('2d')!);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
let glowTexCache: THREE.Texture | null = null;
function glowTexture() {
  if (glowTexCache) return glowTexCache;
  glowTexCache = canvasTex(128, 128, (g) => {
    const grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
    grd.addColorStop(0, 'rgba(255,255,255,1)');
    grd.addColorStop(0.18, 'rgba(255,255,255,0.65)');
    grd.addColorStop(0.45, 'rgba(255,255,255,0.16)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.fillRect(0, 0, 128, 128);
  });
  return glowTexCache;
}
function ringTexture() {
  return canvasTex(256, 256, (g) => {
    const grd = g.createRadialGradient(128, 128, 60, 128, 128, 128);
    grd.addColorStop(0, 'rgba(255,255,255,0)');
    grd.addColorStop(0.55, 'rgba(255,255,255,0.9)');
    grd.addColorStop(0.7, 'rgba(255,255,255,0.25)');
    grd.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grd;
    g.fillRect(0, 0, 256, 256);
  });
}

/**
 * The shared website charger model prints "CCS2 · DC" on its screen. The service offers home (AC) charging, so the app
 * relabels the screen "Type 2 · AC" whenever the charger redraws it (same key the charger uses — no per-frame uploads).
 */
function homeChargerScreen(ch: ReturnType<typeof createCharger>) {
  let tex: THREE.CanvasTexture | null = null;
  ch.group.traverse((o) => {
    const m = (o as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined;
    const t = (m?.map || m?.emissiveMap) as THREE.CanvasTexture | null | undefined;
    if (!tex && t && (t as THREE.CanvasTexture).isCanvasTexture) tex = t;
  });
  const paint = () => {
    if (!tex) return;
    const c = tex.image as HTMLCanvasElement;
    const g = c.getContext('2d');
    if (!g) return;
    const bg = g.createLinearGradient(0, 0, 0, c.height);
    bg.addColorStop(0, '#163832');
    bg.addColorStop(1, '#051F20');
    g.fillStyle = bg;
    g.fillRect(80, 28, c.width - 80, 30);
    g.fillStyle = '#8EB69B';
    g.font = '600 18px sans-serif';
    g.fillText('Type 2  ·  AC', 84, 50);
    tex.needsUpdate = true;
  };
  const draw = ch.setState;
  let last = '';
  ch.setState = (s) => {
    draw(s);
    const key = `${s.mode}|${Math.round(s.percent)}|${s.theme}`;
    if (key !== last) (last = key), paint();
  };
  paint();
  return ch;
}

export class EvStage {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(30, 1, 0.1, 160);
  onCue?: (cue: IntroCue) => void;
  onContextLost?: () => void;
  realisticCar = false;
  ready = false;

  private o: StageOptions;
  private themeName: StageTheme;
  private look: Look;
  private m = createConnectorMaterials();
  private shell = new THREE.MeshPhysicalMaterial({ color: '#f4faf6', roughness: 0.22, metalness: 0.1, clearcoat: 1, clearcoatRoughness: 0.06 });
  private charger!: ReturnType<typeof createCharger>;
  private charger2!: ReturnType<typeof createCharger>;
  private connector!: ReturnType<typeof createConnector>;
  private car!: CarRig;
  private cable!: Cable;
  private cable2!: Cable;
  private hemi = new THREE.HemisphereLight();
  private key = new THREE.DirectionalLight();
  private rim = new THREE.DirectionalLight();
  private chargerLight = new THREE.PointLight(PALETTE.sage, 0, 5, 1.6);
  private portLight = new THREE.PointLight(PALETTE.mint, 0, 2.2, 2);
  private headLight = new THREE.SpotLight('#ffffff', 0, 14, 0.5, 0.6, 1.4);

  // environment
  private floorMat = new THREE.MeshStandardMaterial({ roughness: 0.38, metalness: 0.05, transparent: true });
  private lineMat = new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false });
  private wallMat = new THREE.MeshPhysicalMaterial({ roughness: 0.3, metalness: 0.1, clearcoat: 0.6 });
  private finMats: THREE.MeshBasicMaterial[] = [];
  private laneMat: THREE.MeshBasicMaterial | null = null;
  private cityMat = new THREE.MeshStandardMaterial({ roughness: 0.9 });
  private windowMat = new THREE.MeshBasicMaterial({ transparent: true, depthWrite: false });
  private hedgeMat = new THREE.MeshStandardMaterial({ roughness: 0.85 });
  private canopyGlowMat = new THREE.MeshBasicMaterial({ color: PALETTE.mint, toneMapped: false });
  private aoMats: THREE.MeshBasicMaterial[] = [];
  private reflector: Reflector | null = null;
  private bgTex: THREE.CanvasTexture | null = null;

  // light effects
  private glows: { sprite: THREE.Sprite; base: number; key: 'cap' | 'strip' | 'port' | 'head' | 'canopy' | 'charger2' }[] = [];
  private groundRing!: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshBasicMaterial>;
  private flash!: THREE.Sprite;
  private orbs: THREE.Sprite[] = [];
  private particles!: THREE.Points<THREE.BufferGeometry, THREE.PointsMaterial>;
  private particleSeeds: Float32Array = new Float32Array(0);
  private carLights: THREE.MeshStandardMaterial[] = [];

  // choreography state (tweened by GSAP)
  private st = { drive: 1, door: 1, travel: 1, insert: 1, latch: 0, charge: 1, percent: 64, flash: 0, wall: 1, lights: 1, sweep: 0, camK: -1 };
  /** intro camera keyframes; st.camK (tweened, seekable) moves between them */
  private camKeys: CamPose[] = [];
  private cam = { t: 0 };
  private camFrom: CamPose = { pos: v3(0, 0, 0), tgt: v3(0, 0, 0), fov: 30 };
  private camTo: CamPose = { pos: v3(0, 0, 0), tgt: v3(0, 0, 0), fov: 30 };
  private tl: gsap.core.Timeline | null = null;

  // connection geometry
  private holsterPos = new THREE.Vector3();
  private holsterQuat = new THREE.Quaternion();
  private seatPos = new THREE.Vector3();
  private prePos = new THREE.Vector3();
  private seatQuat = new THREE.Quaternion();
  private portNormal = new THREE.Vector3();
  private portWorld = new THREE.Vector3();
  private travel!: THREE.CatmullRomCurve3;
  private spinWheels: THREE.Object3D[] = [];
  private carBody: THREE.Object3D | null = null;

  private size = { w: 1, h: 1 };
  private dpr = 1;
  private running = false;
  private paused = false;
  private disposed = false;
  private last = 0;
  private time = 0;
  private acc = 0;
  private frames: number[] = [];
  private pointer = { x: 0, y: 0, cx: 0, cy: 0 };
  private tmpQ = new THREE.Quaternion();

  constructor(o: StageOptions) {
    this.o = o;
    this.themeName = o.theme;
    this.look = LOOKS[o.theme];
    const r = new THREE.WebGLRenderer({ canvas: o.canvas, antialias: o.quality === 'high', alpha: false, powerPreference: 'high-performance' });
    r.toneMapping = THREE.ACESFilmicToneMapping;
    r.outputColorSpace = THREE.SRGBColorSpace;
    r.shadowMap.enabled = true;
    r.shadowMap.type = THREE.PCFShadowMap;
    this.dpr = Math.min(window.devicePixelRatio || 1, o.mode === 'intro' && o.quality === 'high' ? 2 : o.quality === 'high' ? 1.75 : 1.25);
    r.setPixelRatio(this.dpr);
    this.renderer = r;
    o.canvas.addEventListener('webglcontextlost', this.handleLost);
    const pm = new THREE.PMREMGenerator(r);
    this.scene.environment = pm.fromScene(new RoomEnvironment(), 0.035).texture;
    pm.dispose();
  }

  // ------------------------------------------------------------------------------------------------ build
  async init(onProgress?: (p: number) => void, modelTimeoutMs = 0) {
    const q = this.o.quality;
    this.buildEnvironment();
    this.scene.add(this.hemi, this.key, this.rim, this.chargerLight, this.portLight, this.headLight, this.headLight.target);
    this.key.position.set(5, 9, 6);
    this.key.castShadow = true;
    const sm = q === 'high' ? 2048 : 1024;
    this.key.shadow.mapSize.set(sm, sm);
    Object.assign(this.key.shadow.camera, { left: -7, right: 7, top: 7, bottom: -6, near: 1, far: 26 });
    this.key.shadow.bias = -0.0004;
    this.key.shadow.normalBias = 0.02;
    this.rim.position.set(-6, 4, -7);

    // primary charger + handle
    this.charger = homeChargerScreen(createCharger(this.m, this.shell));
    this.charger.group.position.copy(CHARGER_POS);
    this.charger.group.rotation.y = CHARGER_ROT;
    this.scene.add(this.charger.group);
    this.connector = createConnector(this.m);
    this.scene.add(this.connector.group);
    this.chargerLight.position.copy(CHARGER_POS).add(v3(-0.2, 1.5, 0.5));
    this.addAO(this.charger.group, 1.2, 1.0, 0.7);

    // second bay charger (midground), idle, with its handle holstered
    this.charger2 = homeChargerScreen(createCharger(this.m, this.shell));
    this.charger2.group.position.copy(CHARGER2_POS);
    this.charger2.group.rotation.y = CHARGER2_ROT;
    this.scene.add(this.charger2.group);
    this.addAO(this.charger2.group, 1.2, 1.0, 0.7);
    const idle = createConnector(this.m);
    this.scene.add(idle.group);
    this.scene.updateMatrixWorld(true);
    this.charger2.holsterPose.getWorldPosition(idle.group.position);
    this.charger2.holsterPose.getWorldQuaternion(idle.group.quaternion);
    idle.group.updateMatrixWorld(true);
    this.cable2 = new Cable({ length: 1.25, points: 18, radius: 0.016, rings: 40, radial: 8 });
    this.cable2.start.copy(this.charger2.outletPoint.getWorldPosition(new THREE.Vector3()));
    this.cable2.startDir.set(-1, -0.6, 0).applyAxisAngle(v3(0, 1, 0), CHARGER2_ROT).normalize();
    this.cable2.end.copy(idle.cableExit).applyMatrix4(idle.group.matrixWorld);
    this.cable2.endDir.copy(idle.cableDir).transformDirection(idle.group.matrixWorld);
    this.cable2.addCollider(new THREE.Box3(v3(-0.26, 0, -0.18), v3(0.26, 1.82, 0.18)), this.charger2.group.matrixWorld);
    this.cable2.reset(240);
    this.scene.add(this.cable2.mesh);
    this.charger2.setState({ mode: 'ready', percent: 0, kw: 0, theme: this.themeName });

    // car (licensed model, or the procedural fallback when disabled / slow / unavailable)
    let car: CarRig | null = null;
    if (this.o.useModel) {
      const load = loadCar(this.o.modelUrl, this.m, onProgress).catch(() => null);
      car = modelTimeoutMs ? await Promise.race([load, new Promise<null>((r) => setTimeout(() => r(null), modelTimeoutMs))]) : await load;
    }
    if (this.disposed) return;
    this.realisticCar = !!car;
    this.car = car || proceduralCar(this.m);
    if (!car) this.addFallbackLights(this.car);
    this.scene.add(this.car.group);
    this.addAO(this.car.group, 2.6, 5.2, 0.9);
    this.car.group.traverse((ob) => {
      const mat = (ob as THREE.Mesh).material as THREE.MeshStandardMaterial | undefined;
      if (mat && /Headlight|Signallight|FallbackLight/.test(mat.name) && !this.carLights.includes(mat)) this.carLights.push(mat);
    });
    this.carBody = this.car.group.children[0] ?? null;
    // Wheels roll about their own hub. The licensed GLB parents each wheel's rim, tyre and disc under a node whose
    // pivot is the car origin (not the hub), so rotating that node swung the wheel around the car — it was skipped,
    // leaving the wheels frozen. Re-pivot: a hub node at the centre of the rotating parts (rim + tyre + disc; the brake
    // caliper stays fixed), spun about the car's lateral axis by distance / radius.
    this.scene.updateMatrixWorld(true);
    for (const w of this.car.wheels) {
      if (!w.parent) continue;
      const box = new THREE.Box3().setFromObject(w);
      const hubWorld = box.getCenter(new THREE.Vector3());
      let spin: THREE.Object3D = w;
      if (hubWorld.distanceTo(w.getWorldPosition(new THREE.Vector3())) >= 0.04) {
        const rotating = w.children.filter((c) => !/BrakePad|Caliper/i.test(c.name));
        if (!rotating.length) continue;
        const rb = new THREE.Box3();
        rotating.forEach((c) => rb.expandByObject(c));
        rb.getCenter(hubWorld);
        const hub = new THREE.Object3D();
        hub.name = `${w.name}Hub`;
        w.add(hub);
        hub.position.copy(w.worldToLocal(hubWorld.clone()));
        hub.updateMatrixWorld(true);
        rotating.forEach((c) => hub.attach(c)); // keeps each part exactly where it was
        spin = hub;
      }
      const size = new THREE.Box3().setFromObject(spin).getSize(new THREE.Vector3());
      // the axle is the car's lateral (world X) axis, expressed in the spinning node's parent space
      const inv = new THREE.Matrix4().copy(spin.parent!.matrixWorld).invert();
      spin.userData.axle = new THREE.Vector3(1, 0, 0).transformDirection(inv).normalize();
      spin.userData.radius = Math.max(0.2, Math.max(size.y, size.z) / 2) || 0.34;
      this.spinWheels.push(spin);
    }

    this.computeConnectionGeometry();

    // the charging cable
    const outlet = this.charger.outletPoint.getWorldPosition(new THREE.Vector3());
    this.cable = new Cable({ length: 3.1, points: 42, radius: 0.016, rings: q === 'high' ? 110 : 64 });
    this.cable.start.copy(outlet);
    this.cable.startDir.set(-1, -0.6, 0).applyAxisAngle(v3(0, 1, 0), CHARGER_ROT).normalize();
    this.cable.addCollider(this.car.bodyBox, this.car.group.matrixWorld);
    this.cable.addCollider(new THREE.Box3(v3(-0.26, 0, -0.18), v3(0.26, 1.82, 0.18)), this.charger.group.matrixWorld);
    this.scene.add(this.cable.mesh);

    this.buildEffects();
    this.applyTheme();

    // starting state
    if (this.o.mode === 'intro' && !this.o.reducedMotion) {
      Object.assign(this.st, { drive: 0, door: 0, travel: 0, insert: 0, latch: 0, charge: 0, percent: 18, flash: 0, wall: 0, lights: 0, sweep: 0 });
    }
    this.updateConnection(0);
    this.cable.reset(320);
    this.setCamera(this.preset(this.o.mode === 'intro' && !this.o.reducedMotion ? 'introStart' : this.o.mode), true);
    this.updateFrame(0);
    try {
      await this.renderer.compileAsync(this.scene, this.camera);
    } catch {
      /* compiles on first render */
    }
    this.ready = true;
  }

  private computeConnectionGeometry() {
    // poses are computed with the car parked at the origin
    const z = this.car.group.position.z;
    this.car.group.position.z = 0;
    this.scene.updateMatrixWorld(true);
    this.charger.holsterPose.getWorldPosition(this.holsterPos);
    this.charger.holsterPose.getWorldQuaternion(this.holsterQuat);
    const port = this.car.port;
    port.getWorldQuaternion(this.tmpQ);
    port.getWorldPosition(this.portWorld);
    this.portNormal.set(0, 0, 1).applyQuaternion(this.tmpQ);
    this.seatQuat.copy(this.tmpQ).multiply(new THREE.Quaternion().setFromAxisAngle(v3(0, 1, 0), Math.PI));
    port.localToWorld(this.seatPos.set(0, 0, COLLAR_DEPTH - 0.012 + 0.003));
    this.prePos.copy(this.seatPos).addScaledVector(this.portNormal, 0.2);
    const out = v3(0, 0, -1).applyQuaternion(this.holsterQuat);
    const h1 = this.holsterPos.clone().addScaledVector(out, 0.16).add(v3(0, 0.1, 0));
    const pre1 = this.prePos.clone().addScaledVector(this.portNormal, 0.16).add(v3(0, 0.06, 0));
    const mid = h1.clone().lerp(pre1, 0.5).add(v3(0, 0.22, 0)).addScaledVector(this.portNormal, 0.25);
    this.travel = new THREE.CatmullRomCurve3([this.holsterPos.clone(), h1, mid, pre1, this.prePos.clone()], false, 'centripetal');
    this.car.group.position.z = z;
    this.scene.updateMatrixWorld(true);
  }

  private addFallbackLights(car: CarRig) {
    const mat = new THREE.MeshStandardMaterial({ name: 'FallbackLight', color: '#ffffff', emissive: '#ffffff', emissiveIntensity: 0.6 });
    for (const x of [-0.62, 0.62]) {
      const l = new THREE.Mesh(new RoundedBoxGeometry(0.42, 0.06, 0.05, 2, 0.02), mat);
      l.position.set(x, 0.72, 2.36);
      car.group.add(l);
    }
  }

  private addAO(parent: THREE.Object3D, w: number, d: number, opacity: number) {
    const tex = canvasTex(128, 128, (g) => {
      const grd = g.createRadialGradient(64, 64, 4, 64, 64, 64);
      grd.addColorStop(0, 'rgba(0,0,0,1)');
      grd.addColorStop(0.5, 'rgba(0,0,0,.5)');
      grd.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = grd;
      g.fillRect(0, 0, 128, 128);
    });
    const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity, depthWrite: false, color: '#0b2b26' });
    mat.userData.base = opacity;
    const ao = new THREE.Mesh(new THREE.PlaneGeometry(w, d), mat);
    ao.rotation.x = -Math.PI / 2;
    ao.position.y = 0.006;
    ao.renderOrder = 2;
    parent.add(ao);
    this.aoMats.push(mat);
  }

  private buildEnvironment() {
    const q = this.o.quality;
    // floor (reflective in the high-quality intro)
    if (q === 'high' && this.o.mode === 'intro') {
      this.reflector = new Reflector(new THREE.PlaneGeometry(60, 60), { textureWidth: 1024, textureHeight: 1024, color: 0x889990 });
      this.reflector.rotation.x = -Math.PI / 2;
      this.reflector.position.y = -0.002;
      this.scene.add(this.reflector);
    }
    const floor = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), this.floorMat);
    floor.rotation.x = -Math.PI / 2;
    floor.receiveShadow = true;
    this.scene.add(floor);

    // painted bays: lines + brand mark (one texture for 16 m × 12 m)
    const lines = new THREE.Mesh(new THREE.PlaneGeometry(16, 12), this.lineMat);
    lines.rotation.x = -Math.PI / 2;
    lines.position.set(0, 0.004, 0.2);
    lines.renderOrder = 1;
    this.scene.add(lines);

    // back wall with light fins (they light up in sequence when charging starts)
    // back wall in two halves: the charging lane is drive-through, so the EV can arrive nose-first
    for (const x of [-4.15, 4.15]) {
      const wall = new THREE.Mesh(new RoundedBoxGeometry(4.7, 2.6, 0.3, 3, 0.08), this.wallMat);
      wall.position.set(x, 1.3, -3.4);
      wall.receiveShadow = wall.castShadow = true;
      this.scene.add(wall);
    }
    const finGeo = new RoundedBoxGeometry(0.07, 1.9, 0.04, 2, 0.02);
    for (let i = 0; i < 15; i++) {
      const x = -6 + i * (12 / 14);
      if (Math.abs(x) < 1.9) continue;
      const mat = new THREE.MeshBasicMaterial({ color: PALETTE.mint, toneMapped: false, transparent: true });
      const fin = new THREE.Mesh(finGeo, mat);
      fin.position.set(x, 1.3, -3.24);
      fin.userData.order = Math.abs(x) / 6;
      this.scene.add(fin);
      this.finMats.push(mat);
      mat.userData.order = Math.abs(x) / 6;
    }
    // lane markers leading into the bay (arrival path)
    const laneMat = new THREE.MeshBasicMaterial({ color: PALETTE.mint, toneMapped: false, transparent: true, opacity: 0 });
    laneMat.userData.lane = true;
    for (let i = 0; i < 9; i++) {
      const dash = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 0.9), laneMat);
      dash.rotation.x = -Math.PI / 2;
      dash.position.set(0, 0.008, -4.2 - i * 1.6);
      this.scene.add(dash);
    }
    this.laneMat = laneMat;
    // canopy over the bays
    const canopy = new THREE.Mesh(new RoundedBoxGeometry(9.5, 0.16, 4.6, 3, 0.06), this.wallMat);
    canopy.position.set(0, 3.35, -1.25);
    canopy.castShadow = true;
    this.scene.add(canopy);
    const glow = new THREE.Mesh(new RoundedBoxGeometry(8.6, 0.02, 0.09, 2, 0.01), this.canopyGlowMat);
    glow.position.set(0, 3.262, 0.6);
    this.scene.add(glow);
    for (const x of [-4.4, 4.4]) {
      const post = new THREE.Mesh(new RoundedBoxGeometry(0.18, 3.35, 0.18, 2, 0.05), this.wallMat);
      post.position.set(x, 1.67, -3.1);
      post.castShadow = true;
      this.scene.add(post);
    }
    // planters
    for (const [x, z, w] of [
      [-5.4, -2.75, 1.5],
      [5.4, -2.75, 1.5],
    ] as const) {
      const p = new THREE.Mesh(new RoundedBoxGeometry(w, 0.42, 0.55, 3, 0.12), this.hedgeMat);
      p.position.set(x, 0.21, z);
      p.castShadow = p.receiveShadow = true;
      this.scene.add(p);
    }
    // distant city blocks (background layer, softened by fog)
    let seed = 7;
    const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;
    const winTex = canvasTex(64, 128, (g) => {
      g.clearRect(0, 0, 64, 128);
      g.fillStyle = '#fff';
      for (let y = 6; y < 124; y += 10) for (let x = 6; x < 60; x += 12) if (((x * 7 + y * 3) % 5) > 1) g.fillRect(x, y, 6, 5);
    });
    winTex.wrapS = winTex.wrapT = THREE.RepeatWrapping;
    this.windowMat.map = winTex;
    for (let i = 0; i < 22; i++) {
      const w = 1.6 + rnd() * 2.4;
      const h = 2.5 + rnd() * 9;
      const d = 1.5 + rnd() * 2;
      const x = -26 + i * 2.5 + rnd();
      const z = -16 - rnd() * 12;
      const b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), this.cityMat);
      b.position.set(x, h / 2, z);
      this.scene.add(b);
      const win = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.8, h * 0.85), this.windowMat);
      win.position.set(x, h / 2, z + d / 2 + 0.01);
      (win.material as THREE.MeshBasicMaterial).map!.repeat.set(1, 1);
      this.scene.add(win);
    }
    this.scene.fog = new THREE.Fog(this.look.fog, 16, 46);
  }

  private makeGlow(color: string, size: number, key: EvStage['glows'][number]['key'], pos: THREE.Vector3, base = 1, parent: THREE.Object3D = this.scene) {
    const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, toneMapped: false }));
    s.scale.setScalar(size);
    s.position.copy(pos);
    parent.add(s);
    this.glows.push({ sprite: s, base, key });
    return s;
  }

  private buildEffects() {
    this.scene.updateMatrixWorld(true);
    const cg = this.charger.group;
    this.makeGlow(PALETTE.mint, 0.9, 'cap', cg.localToWorld(v3(0, 1.73, 0.05)), 0.75);
    this.makeGlow(PALETTE.sage, 0.7, 'strip', cg.localToWorld(v3(0.215, 1.0, 0.2)), 0.7);
    this.makeGlow(PALETTE.mint, 0.7, 'charger2', this.charger2.group.localToWorld(v3(0, 1.73, 0.05)), 0.45);
    this.makeGlow(PALETTE.mint, 0.55, 'port', this.seatPos.clone().addScaledVector(this.portNormal, 0.05), 1);
    const front = this.car.bodyBox.max.z + 0.1;
    for (const x of [-0.62, 0.62]) this.makeGlow('#ffffff', 0.85, 'head', v3(x, 0.72, front), 0.8, this.car.group);
    for (const x of [-3, 0, 3]) this.makeGlow(PALETTE.mint, 1.6, 'canopy', v3(x, 3.2, 0.62), 0.35);
    this.flash = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTexture(), color: PALETTE.mint, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, toneMapped: false }));
    this.flash.position.copy(this.seatPos).addScaledVector(this.portNormal, 0.06);
    this.scene.add(this.flash);

    // energy ring on the floor around the car
    this.groundRing = new THREE.Mesh(
      new THREE.PlaneGeometry(6.4, 6.4),
      new THREE.MeshBasicMaterial({ map: ringTexture(), color: PALETTE.sage, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false }),
    );
    this.groundRing.rotation.x = -Math.PI / 2;
    this.groundRing.position.set(0.2, 0.012, 0.1);
    this.groundRing.renderOrder = 3;
    this.scene.add(this.groundRing);

    // energy orbs that ride the cable rope
    const orbMat = new THREE.SpriteMaterial({ map: glowTexture(), color: PALETTE.mint, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0, toneMapped: false });
    for (let i = 0; i < 5; i++) {
      const s = new THREE.Sprite(orbMat.clone());
      s.scale.setScalar(0.16);
      this.scene.add(s);
      this.orbs.push(s);
    }

    // drifting particles in the bay volume
    const n = this.o.quality === 'high' ? 260 : 120;
    const pos = new Float32Array(n * 3);
    this.particleSeeds = new Float32Array(n * 4);
    for (let i = 0; i < n; i++) {
      const s = this.particleSeeds;
      s[i * 4] = (Math.random() - 0.5) * 12;
      s[i * 4 + 1] = Math.random() * 3.6;
      s[i * 4 + 2] = -3 + Math.random() * 7;
      s[i * 4 + 3] = Math.random();
      pos.set([s[i * 4], s[i * 4 + 1], s[i * 4 + 2]], i * 3);
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3).setUsage(THREE.DynamicDrawUsage));
    this.particles = new THREE.Points(
      geo,
      new THREE.PointsMaterial({ map: glowTexture(), size: 0.07, sizeAttenuation: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.4, toneMapped: false }),
    );
    this.particles.frustumCulled = false;
    this.scene.add(this.particles);
  }

  // ------------------------------------------------------------------------------------------------ theme
  setTheme(name: StageTheme) {
    if (name === this.themeName) return;
    this.themeName = name;
    this.look = LOOKS[name];
    this.applyTheme();
    if (!this.running || this.paused) this.renderOnce();
  }

  private applyTheme() {
    const t = SCENE_THEMES[this.themeName];
    const L = this.look;
    const dark = this.themeName === 'dark';
    this.renderer.toneMappingExposure = t.exposure * (dark ? 1 : 0.8); // more contrast for the light scene
    this.scene.environmentIntensity = t.env;
    this.hemi.color.set(t.hemi[0]);
    this.hemi.groundColor.set(t.hemi[1]);
    this.hemi.intensity = t.hemi[2];
    this.key.color.set(t.key[0]);
    this.key.intensity = t.key[1];
    this.rim.color.set(t.rim[0]);
    this.rim.intensity = t.rim[1];
    this.shell.color.set(t.shell);
    if (this.car) this.car.paint.color.set(t.paint);
    // background gradient + fog
    this.bgTex?.dispose();
    this.bgTex = canvasTex(4, 256, (g) => {
      const grd = g.createLinearGradient(0, 0, 0, 256);
      grd.addColorStop(0, L.bgTop);
      grd.addColorStop(0.62, L.fog);
      grd.addColorStop(1, L.bgBottom);
      g.fillStyle = grd;
      g.fillRect(0, 0, 4, 256);
    });
    this.scene.background = this.bgTex;
    (this.scene.fog as THREE.Fog).color.set(L.fog);
    this.floorMat.color.set(L.floor);
    this.floorMat.opacity = this.reflector ? (dark ? 0.8 : 0.86) : 1;
    this.lineMat.map?.dispose();
    this.lineMat.map = canvasTex(1024, 768, (g) => this.drawBays(g, 1024, 768));
    this.lineMat.needsUpdate = true;
    this.wallMat.color.set(L.wall);
    this.cityMat.color.set(L.city);
    this.windowMat.color.set(L.window);
    this.windowMat.opacity = dark ? 0.55 : 0.0;
    this.hedgeMat.color.set(L.hedge);
    this.canopyGlowMat.color.set(dark ? PALETTE.mint : '#ffffff');
    this.aoMats.forEach((m) => (m.opacity = (m.userData.base as number) * L.shadow));
    this.particles?.material.color.set(L.particles);
    this.carLights.forEach((m) => {
      m.emissive = new THREE.Color(dark ? '#DAF1DE' : '#ffffff');
    });
    for (const c of [this.cable, this.cable2]) c?.uniforms.uGlow.value.set(dark ? PALETTE.sage : PALETTE.moss);
    this.charger?.capGlowMat.color.set(dark ? PALETTE.mint : '#ffffff');
    this.charger2?.capGlowMat.color.set(dark ? PALETTE.mint : '#ffffff');
    this.charger2?.setState({ mode: 'ready', percent: 0, kw: 0, theme: this.themeName });
    this.groundRing?.material.color.set(dark ? PALETTE.sage : PALETTE.moss);
    for (const g of this.glows) (g.sprite.material as THREE.SpriteMaterial).color.set(g.key === 'head' ? '#ffffff' : dark ? PALETTE.mint : g.key === 'strip' ? PALETTE.moss : PALETTE.sage);
  }

  private drawBays(g: CanvasRenderingContext2D, W: number, H: number) {
    const L = this.look;
    g.clearRect(0, 0, W, H);
    const m = W / 16; // 1 m in px; plane is 16 m × 12 m centred at (0, 0.2)
    const X = (x: number) => W / 2 + x * m;
    const Z = (z: number) => H / 2 + (z - 0.2) * m;
    g.strokeStyle = L.line;
    g.lineWidth = m * 0.08;
    g.lineCap = 'round';
    g.globalAlpha = 0.9;
    g.beginPath();
    for (const x of [-4.4, -1.45, 1.45, 4.4]) {
      g.moveTo(X(x), Z(3.4));
      g.lineTo(X(x), Z(-2.9));
    }
    g.moveTo(X(-4.4), Z(-2.9));
    g.lineTo(X(4.4), Z(-2.9));
    g.stroke();
    g.globalAlpha = 0.16;
    g.fillStyle = this.themeName === 'dark' ? PALETTE.sage : PALETTE.moss;
    g.fillRect(X(-1.4), Z(-2.85), 2.8 * m, 6.2 * m);
    g.globalAlpha = 0.5;
    g.save();
    g.translate(X(-0.55), Z(2.2));
    drawMark(g, 1.1 * m, L.line, L.line);
    g.restore();
    g.save();
    g.translate(X(-3.45), Z(2.2));
    drawMark(g, 1.1 * m, L.line, L.line);
    g.restore();
    g.globalAlpha = 1;
  }

  // ------------------------------------------------------------------------------------------------ camera
  private preset(name: StageMode | 'introStart' | 'introPort' | 'introReveal'): CamPose {
    const close = this.seatPos.clone().lerp(this.holsterPos, 0.5).add(v3(0, -0.06, 0));
    switch (name) {
      case 'introStart':
        return { pos: v3(2.9, 0.85, 7.2), tgt: v3(0, 0.75, -6), fov: 34 };
      case 'introPort':
        return { pos: close.clone().add(v3(1.9, 0.55, 2.7)), tgt: close, fov: 27 };
      case 'introReveal':
        return { pos: v3(10.4, 2.4, 8.6), tgt: v3(0.9, 0.95, -0.4), fov: 30 };
      case 'station':
        return { pos: v3(6.4, 1.8, 4.9), tgt: v3(1.45, 0.9, -0.1), fov: 30 };
      case 'partner':
        return { pos: v3(8.0, 3.1, 7.6), tgt: v3(0.5, 0.85, -0.6), fov: 30 };
      case 'admin':
        return { pos: v3(6.4, 6.2, 8.4), tgt: v3(0.3, 0.6, -0.7), fov: 30 };
      case 'hero':
      case 'intro':
      default:
        return { pos: v3(8.2, 2.1, 6.6), tgt: v3(0.9, 0.85, -0.2), fov: 30 };
    }
  }

  private setCamera(p: CamPose, instant = false, duration = 1.6, ease = 'power2.inOut') {
    this.camFrom = this.currentCam();
    this.camTo = { pos: p.pos.clone(), tgt: p.tgt.clone(), fov: p.fov };
    gsap.killTweensOf(this.cam);
    if (instant) {
      this.cam.t = 1;
      return null;
    }
    this.cam.t = 0;
    return gsap.to(this.cam, { t: 1, duration, ease });
  }
  private currentCam(): CamPose {
    const k = this.cam.t;
    return {
      pos: this.camFrom.pos.clone().lerp(this.camTo.pos, k),
      tgt: this.camFrom.tgt.clone().lerp(this.camTo.tgt, k),
      fov: this.camFrom.fov + (this.camTo.fov - this.camFrom.fov) * k,
    };
  }

  /** Composition offset in viewport fractions (e.g. -0.18 = shift the scene right). */
  setOffset(x: number, y = 0) {
    this.o.offsetX = x;
    this.o.offsetY = y;
    if (!this.running || this.paused) this.renderOnce();
  }

  private updateCamera() {
    let c = this.currentCam();
    if (this.st.camK >= 0 && this.camKeys.length) {
      const k = Math.min(this.camKeys.length - 1, this.st.camK);
      const i = Math.min(this.camKeys.length - 2, Math.floor(k));
      const f = k - i;
      const a = this.camKeys[i];
      const b = this.camKeys[i + 1];
      c = { pos: a.pos.clone().lerp(b.pos, f), tgt: a.tgt.clone().lerp(b.tgt, f), fov: a.fov + (b.fov - a.fov) * f };
    }
    const { w, h } = this.size;
    const aspect = w / h;
    // narrow viewports: pull back so the car and the charger stay in frame
    const fit = aspect >= 1.35 ? 1 : Math.min(2.1, 1.35 / aspect);
    if (fit > 1) c.pos.sub(c.tgt).multiplyScalar(1 + (fit - 1) * 0.72).add(c.tgt);
    // idle drift + pointer parallax (not in reduced motion)
    if (!this.o.reducedMotion) {
      const sway = this.o.mode === 'intro' ? 0 : Math.sin(this.time * 0.18) * 0.35;
      const e = this.camera.matrixWorld.elements;
      const px = this.pointer.cx * 0.45 + sway;
      const py = this.pointer.cy * 0.22;
      c.pos.x += e[0] * px - e[4] * py;
      c.pos.y += e[1] * px - e[5] * py;
      c.pos.z += e[2] * px - e[6] * py;
    }
    this.camera.position.copy(c.pos);
    this.camera.lookAt(c.tgt);
    this.camera.fov = c.fov;
    const ox = (this.o.offsetX ?? 0) * w * (aspect > 1.05 ? 1 : 0);
    const oy = (this.o.offsetY ?? 0) * h;
    this.camera.setViewOffset(w, h, ox, oy, w, h);
    this.camera.updateProjectionMatrix();
    this.camera.updateMatrixWorld();
  }

  // ------------------------------------------------------------------------------------------------ intro
  /** The cinematic sequence (~7.6 s). Cues let the DOM overlay time the logo reveal and the hand-off. */
  playIntro() {
    if (!this.ready) return null;
    this.tl?.kill();
    const st = this.st;
    const tl = gsap.timeline({ onComplete: () => this.onCue?.('done') });
    const cue = (c: IntroCue) => () => this.onCue?.(c);
    // station powers up
    tl.to(st, { lights: 1, duration: 1.1, ease: 'power2.out' }, 0.1);
    // the EV glides in and settles (wheel spin follows distance)
    tl.call(cue('arrive'), [], 0.2);
    tl.to(st, { drive: 1, duration: 2.5, ease: 'power3.out' }, 0.2);
    this.camKeys = [this.preset('introStart'), this.preset('hero'), this.preset('introPort'), this.preset('introReveal'), { pos: v3(9.2, 6.4, 11.6), tgt: v3(0.6, 0.4, -0.6), fov: 34 }];
    st.camK = 0;
    tl.to(st, { camK: 1, duration: 2.25, ease: 'power2.inOut' }, 0.25);
    // inlet door opens, camera moves in to the port, handle lifts and aligns
    tl.to(st, { door: 1, duration: 0.7, ease: 'power2.out' }, 2.55);
    tl.to(st, { camK: 2, duration: 1.55, ease: 'power2.inOut' }, 2.5);
    tl.call(cue('plug'), [], 2.7);
    tl.to(st, { travel: 1, duration: 1.6, ease: 'power2.inOut' }, 2.75);
    tl.to(st, { insert: 1, duration: 0.42, ease: 'power3.in' }, 4.35);
    tl.to(st, { latch: 1, duration: 0.1, yoyo: true, repeat: 1 }, 4.78);
    // connection: flash, energy pulse, station lights respond
    tl.call(cue('charge'), [], 4.78);
    tl.fromTo(st, { flash: 0 }, { flash: 1, duration: 0.18, ease: 'power2.out' }, 4.78);
    tl.to(st, { flash: 0, duration: 0.9, ease: 'power2.in' }, 4.98);
    tl.to(st, { charge: 1, duration: 0.8, ease: 'power2.out' }, 4.85);
    tl.to(st, { wall: 1, duration: 1.1, ease: 'power1.inOut' }, 4.9);
    tl.to(st, { percent: 72, duration: 2.6, ease: 'none' }, 4.95);
    // pull back for the logo reveal, then rise into the dashboard
    tl.to(st, { camK: 3, duration: 1.75, ease: 'power2.inOut' }, 5.25);
    tl.call(cue('reveal'), [], 5.6);
    tl.to(st, { sweep: 1, duration: 1.2, ease: 'power1.inOut' }, 5.7);
    tl.to(st, { camK: 4, duration: 1.3, ease: 'power2.in' }, 7.0);
    tl.call(cue('exit'), [], 7.15);
    tl.to({}, { duration: 0.01 }, 8.25);
    this.tl = tl;
    return tl;
  }

  skipIntro() {
    this.tl?.progress(1);
  }

  /** QA hook: freeze the intro at a given second so screenshots are deterministic on slow (software) renderers. */
  seekIntro(t: number) {
    if (!this.tl) return;
    this.tl.pause();
    this.tl.seek(t, false);
    // let the cable simulation settle into the new pose (simulation only, no rendering), then hold a still frame:
    // no render loop while a slow (software) renderer is being photographed
    for (let i = 0; i < 90; i++) {
      this.time += 1 / 60;
      this.updateFrame(1 / 60);
    }
    this.setPaused(true);
    this.renderOnce();
  }

  // ------------------------------------------------------------------------------------------------ per frame
  private updateConnection(dt: number) {
    const st = this.st;
    const conn = this.connector.group;
    if (st.insert > 0) {
      conn.position.lerpVectors(this.prePos, this.seatPos, st.insert);
      conn.quaternion.copy(this.seatQuat);
    } else if (st.travel > 0) {
      this.travel.getPoint(st.travel, conn.position);
      conn.quaternion.slerpQuaternions(this.holsterQuat, this.seatQuat, smooth(0.12, 0.88, st.travel));
    } else {
      conn.position.copy(this.holsterPos);
      conn.quaternion.copy(this.holsterQuat);
    }
    this.connector.latch.position.y = 0.052 - st.latch * 0.006;
    this.car.inlet.door.rotation.y = st.door * 1.95;
    const led = this.car.inlet.led.material;
    if (st.charge > 0) {
      led.emissive.set(PALETTE.sage);
      led.emissiveIntensity = 2.2 * st.charge * (0.65 + 0.35 * Math.sin(this.time * 3.2)) + 0.4;
    } else {
      led.emissive.setRGB(1, 1, 1);
      led.emissiveIntensity = smooth(0.2, 1, st.door) * 1.2;
    }
    conn.updateMatrixWorld();
    this.cable.end.copy(this.connector.cableExit).applyMatrix4(conn.matrixWorld);
    this.cable.endDir.copy(this.connector.cableDir).transformDirection(conn.matrixWorld);
    this.cable.uniforms.uCharging.value = st.charge;
    this.cable.update(dt, this.time);
    this.cable.uniforms.uTime.value = this.time;
    this.cable2.uniforms.uTime.value = this.time;
    this.charger.setState({ mode: st.charge > 0.05 ? 'charging' : st.travel > 0 || st.door > 0 ? 'connecting' : 'ready', percent: st.percent, kw: 0, theme: this.themeName });
  }

  private updateFrame(dt: number) {
    if (!this.car) return;
    const st = this.st;
    const dark = this.themeName === 'dark';
    const k = 1 - Math.pow(0.002, dt || 1);
    this.pointer.cx += (this.pointer.x - this.pointer.cx) * k;
    this.pointer.cy += (this.pointer.y - this.pointer.cy) * k;

    // car drive-in: distance-based wheel spin, braking pitch
    const DRIVE = 15;
    const z = -(1 - st.drive) * DRIVE; // arrives nose-first along the drive-through lane
    const dz = z - this.car.group.position.z;
    this.car.group.position.z = z;
    // rolling without slipping: angle = distance / radius; forward travel (+z) turns the contact patch backwards
    if (dz !== 0) for (const w of this.spinWheels) w.quaternion.premultiply(this.tmpQ.setFromAxisAngle(w.userData.axle as THREE.Vector3, dz / (w.userData.radius as number)));
    if (this.carBody) {
      const decel = st.drive > 0.6 && st.drive < 0.995 ? Math.sin(((st.drive - 0.6) / 0.4) * Math.PI) * 0.012 : 0;
      this.carBody.rotation.x = decel;
    }
    const headOn = this.o.mode === 'intro' ? 1 - smooth(0.85, 1, st.drive) * 0.6 : 0.35;
    this.carLights.forEach((m) => (m.emissiveIntensity = (dark ? 2.2 : 0.7) * Math.max(0.3, headOn)));
    this.headLight.intensity = this.o.mode === 'intro' ? (dark ? 18 : 6) * (1 - smooth(0.9, 1, st.drive)) : 0;
    this.headLight.position.set(0, 0.75, this.car.group.position.z + 2.3);
    this.headLight.target.position.set(0, 0, this.car.group.position.z + 9);

    this.updateConnection(dt);

    // station response
    const breathe = 0.82 + 0.18 * Math.sin(this.time * 2.4);
    this.chargerLight.intensity = (st.lights * 0.6 + st.charge * (dark ? 4.5 : 2)) * breathe;
    this.portLight.position.copy(this.seatPos).addScaledVector(this.portNormal, 0.25);
    this.portLight.intensity = st.flash * 3.2 + st.charge * (dark ? 1.0 : 0.6) * breathe;
    this.canopyGlowMat.color.set(dark ? PALETTE.mint : '#ffffff').multiplyScalar(0.35 + 0.65 * st.lights);
    if (this.laneMat) this.laneMat.opacity = (dark ? 0.55 : 0.4) * st.lights * (1 - smooth(0.7, 1, st.drive) * 0.7);
    this.finMats.forEach((m, i) => {
      const order = (m.userData.order as number) ?? 0; // lights run outwards from the lane
      const on = smooth(order * 0.7, order * 0.7 + 0.3, st.wall);
      const wave = 0.55 + 0.45 * Math.sin(this.time * 2.0 - i * 0.55);
      m.opacity = (dark ? 0.12 : 0.18) + on * (dark ? 0.75 : 0.55) * (0.6 + 0.4 * wave * st.charge);
      m.color.set(dark ? PALETTE.mint : PALETTE.sage);
    });
    for (const g of this.glows) {
      const mat = g.sprite.material as THREE.SpriteMaterial;
      let v = 0;
      if (g.key === 'cap') v = st.lights * (0.5 + 0.5 * st.charge * breathe);
      else if (g.key === 'strip') v = st.charge * breathe;
      else if (g.key === 'port') v = st.charge * (0.6 + 0.4 * Math.sin(this.time * 3.2)) + st.flash;
      else if (g.key === 'head') v = this.o.mode === 'intro' ? (1 - smooth(0.92, 1, st.drive)) * 0.9 + 0.1 : 0.12;
      else if (g.key === 'canopy') v = st.lights;
      else if (g.key === 'charger2') v = st.lights * 0.6;
      mat.opacity = v * g.base * (dark ? 1 : 0.55);
    }
    this.flash.material.opacity = st.flash * 0.7; // restrained: a glint, not a white-out
    this.flash.scale.setScalar(0.3 + st.flash * 1.6);
    const ringPhase = (this.time * 0.45) % 1;
    this.groundRing.material.opacity = st.charge * (dark ? 0.55 : 0.4) * (1 - ringPhase) + st.flash * 0.6;
    this.groundRing.scale.setScalar(0.55 + ringPhase * 0.75 + st.flash * 0.3);

    // energy orbs travel from the charger to the car along the simulated cable
    const rope = (this.cable as unknown as { pos: THREE.Vector3[] }).pos;
    this.orbs.forEach((o, i) => {
      const u = (this.time * 0.42 + i / this.orbs.length) % 1;
      const f = u * (rope.length - 1);
      const a = Math.floor(f);
      o.position.lerpVectors(rope[a], rope[Math.min(rope.length - 1, a + 1)], f - a);
      (o.material as THREE.SpriteMaterial).opacity = st.charge * Math.sin(u * Math.PI) * (dark ? 0.95 : 0.7);
      o.scale.setScalar(0.1 + 0.08 * Math.sin(u * Math.PI));
    });

    // particles drift up; while charging they are gently drawn towards the port
    if (!this.o.reducedMotion || dt === 0) {
      const p = this.particles.geometry.getAttribute('position') as THREE.BufferAttribute;
      const s = this.particleSeeds;
      const pull = st.charge * 0.35;
      for (let i = 0; i < p.count; i++) {
        const ph = (s[i * 4 + 3] + this.time * 0.035 * (0.6 + s[i * 4 + 3])) % 1;
        let x = s[i * 4] + Math.sin(this.time * 0.3 + i) * 0.15;
        let y = s[i * 4 + 1] * 0.3 + ph * 3.6;
        let zz = s[i * 4 + 2] + Math.cos(this.time * 0.25 + i) * 0.15;
        const near = Math.max(0, 1 - Math.hypot(x - this.portWorld.x, zz - this.portWorld.z) / 4);
        x += (this.portWorld.x - x) * pull * near * ph;
        y += (this.portWorld.y - y) * pull * near * ph;
        zz += (this.portWorld.z - zz) * pull * near * ph;
        p.setXYZ(i, x, y, zz);
      }
      p.needsUpdate = true;
    }
    this.particles.material.opacity = this.look.particleOpacity * (0.35 + 0.65 * Math.max(st.lights, st.charge));
  }

  // ------------------------------------------------------------------------------------------------ loop
  setPointer(nx: number, ny: number) {
    this.pointer.x = nx;
    this.pointer.y = ny;
  }

  resize(w: number, h: number) {
    this.size = { w: Math.max(1, Math.round(w)), h: Math.max(1, Math.round(h)) };
    this.renderer.setSize(this.size.w, this.size.h, false);
    this.camera.aspect = this.size.w / this.size.h;
    this.reflector?.getRenderTarget().setSize(Math.round(this.size.w * this.dpr * 0.5), Math.round(this.size.h * this.dpr * 0.5));
    if (this.ready && (!this.running || this.paused)) this.renderOnce();
  }

  start() {
    if (this.running || this.disposed || !this.ready) return;
    this.running = true;
    this.paused = false;
    this.last = performance.now();
    this.renderer.setAnimationLoop(this.loop);
  }

  /** Pause rendering (off-screen / hidden tab); GSAP timelines keep their own clock. */
  setPaused(p: boolean) {
    if (!this.running || p === this.paused) return;
    this.paused = p;
    this.renderer.setAnimationLoop(p ? null : this.loop);
    if (!p) this.last = performance.now();
  }

  stop() {
    this.running = false;
    this.renderer.setAnimationLoop(null);
  }

  private loop = (now: number) => {
    const dt = Math.min(0.05, Math.max(0, (now - this.last) / 1000));
    this.last = now;
    // low quality: cap at ~30 fps
    if (this.o.quality === 'low') {
      this.acc += dt;
      if (this.acc < 1 / 31) return;
      this.tick(this.acc);
      this.acc = 0;
      return;
    }
    this.tick(dt);
  };

  private tick(dt: number) {
    this.time += dt;
    this.adapt(dt);
    this.updateFrame(dt);
    this.updateCamera();
    this.renderer.render(this.scene, this.camera);
  }

  private adapt(dt: number) {
    this.frames.push(dt);
    if (this.frames.length < 60) return;
    const avg = this.frames.reduce((a, b) => a + b, 0) / this.frames.length;
    this.frames.length = 0;
    if (avg > 0.026 && this.dpr > 0.75) {
      this.dpr = Math.max(0.75, this.dpr - 0.25);
      this.renderer.setPixelRatio(this.dpr);
      this.resize(this.size.w, this.size.h);
    }
  }

  /** A single still frame (reduced motion, paused theme switch). */
  renderOnce() {
    if (this.disposed || !this.ready) return;
    this.updateFrame(0);
    this.updateCamera();
    this.renderer.render(this.scene, this.camera);
  }

  diagnostics() {
    return {
      mode: this.o.mode,
      quality: this.o.quality,
      realisticCar: this.realisticCar,
      spinningWheels: this.spinWheels.length,
      wheelAngles: this.spinWheels.map((w) => Math.round(2 * Math.acos(Math.min(1, Math.abs(w.quaternion.w))) * 1000) / 1000),
      dpr: this.dpr,
      running: this.running && !this.paused,
      charge: +this.st.charge.toFixed(2),
      seatGap: +this.connector.group.position.distanceTo(this.seatPos).toFixed(4),
      calls: this.renderer.info.render.calls,
      triangles: this.renderer.info.render.triangles,
    };
  }

  private handleLost = (e: Event) => {
    e.preventDefault();
    this.stop();
    this.onContextLost?.();
  };

  dispose() {
    this.disposed = true;
    this.stop();
    this.tl?.kill();
    gsap.killTweensOf(this.cam);
    gsap.killTweensOf(this.st);
    this.o.canvas.removeEventListener('webglcontextlost', this.handleLost);
    this.scene.traverse((ob) => {
      const mesh = ob as THREE.Mesh;
      mesh.geometry?.dispose();
      const mat = mesh.material as THREE.Material | THREE.Material[] | undefined;
      const mats = Array.isArray(mat) ? mat : mat ? [mat] : [];
      for (const mm of mats) {
        const map = (mm as THREE.MeshBasicMaterial).map;
        if (map && map !== glowTexCache) map.dispose();
        mm.dispose();
      }
    });
    this.bgTex?.dispose();
    this.reflector?.dispose();
    this.scene.environment?.dispose();
    this.renderer.dispose();
    this.renderer.forceContextLoss();
  }
}

export function webglAvailable() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    return false;
  }
}
