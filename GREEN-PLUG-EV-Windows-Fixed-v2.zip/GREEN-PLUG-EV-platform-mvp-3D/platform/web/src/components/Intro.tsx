// Cinematic startup intro (real-time WebGL): an original EV glides into a GREEN PLUG EV charging bay, the inlet door
// opens, the CCS2 handle lifts from the holster and plugs in, an energy pulse runs down the cable while the station
// lights respond, the logo is revealed and the camera rises into the dashboard. ~8 s.
//
// Policy: plays once per browser on an entry page (home / partner / admin dashboards), never on deep links such as
// sign-in, verification or a booking. Skip button + Esc at any time. "Replay intro" lives in Profile. Never shown
// with prefers-reduced-motion. Without WebGL a short 2D brand intro is used instead. The scene is staged at dusk in
// both themes (a deliberate cinematic choice); the app then follows the user's theme.
import { useCallback, useEffect, useRef, useState } from 'react';
import { Logo } from '../../../../src/components/Logo';
import { gsap } from '../../../../src/lib/gsap';
import { prefersReducedMotion } from '../../../../src/lib/prefs';
import type { EvStage, IntroCue } from '../three/EvStage';
import { deviceQuality, hasWebGL, MODEL_URL, threeDEnabled, useModelAllowed } from '../visual/Stage3D';

export const INTRO_KEY = 'gpev-app-intro-seen';
export const REPLAY_EVENT = 'gpev:replay-intro';

export function shouldPlayIntro() {
  return document.documentElement.classList.contains('intro-pending') && !prefersReducedMotion();
}
function markSeen() {
  try {
    localStorage.setItem(INTRO_KEY, '1');
  } catch {
    /* private mode: may replay next time, harmless */
  }
}

export function Intro({ onDone }: { onDone: () => void }) {
  const [webgl] = useState(() => hasWebGL() && threeDEnabled());
  return webgl ? <CinematicIntro onDone={onDone} /> : <IntroLite onDone={onDone} />;
}

function CinematicIntro({ onDone }: { onDone: () => void }) {
  const root = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const skipBtn = useRef<HTMLButtonElement>(null);
  const stageRef = useRef<EvStage | null>(null);
  const [phase, setPhase] = useState<'loading' | 'playing' | 'reveal' | 'exit'>('loading');
  const [progress, setProgress] = useState(0);
  const finished = useRef(false);

  const finish = useCallback(
    (fast = false) => {
      if (finished.current) return;
      finished.current = true;
      markSeen();
      const html = document.documentElement;
      html.classList.remove('intro-pending');
      html.classList.add('intro-handoff');
      setPhase('exit');
      window.setTimeout(
        () => {
          html.classList.remove('intro-active', 'intro-handoff');
          onDone();
        },
        fast ? 380 : 900,
      );
    },
    [onDone],
  );

  useEffect(() => {
    const html = document.documentElement;
    html.classList.remove('intro-pending');
    html.classList.add('intro-active');
    skipBtn.current?.focus({ preventScroll: true });
    let disposed = false;
    let stage: EvStage | null = null;
    // safety net: if the scene is not ready within 9 s (very slow device), go straight to the app;
    // once playing, the whole intro can never hold the app for more than 20 s
    // (`?introwait=<s>` lengthens the wait for software-rendered QA browsers)
    const qaWait = Math.min(600, Number(new URLSearchParams(location.search).get('introwait')) || 0);
    const wait = (qaWait || 9) * 1000;
    const guard = window.setTimeout(() => !stageRef.current?.ready && finish(true), wait);
    const hardStop = window.setTimeout(() => finish(true), qaWait ? wait * 3 : wait + 11000);
    (async () => {
      try {
        const { EvStage } = await import('../three/EvStage');
        if (disposed) return;
        const q = deviceQuality();
        stage = new EvStage({ canvas: canvas.current!, mode: 'intro', theme: 'dark', quality: q, reducedMotion: false, modelUrl: MODEL_URL, useModel: useModelAllowed() });
        stageRef.current = stage;
        (window as unknown as { __gpevIntro?: EvStage }).__gpevIntro = stage;
        stage.onContextLost = () => finish(true);
        stage.resize(window.innerWidth, window.innerHeight);
        await stage.init((p) => setProgress(p), 3200);
        if (disposed || finished.current) return;
        stage.onCue = (c: IntroCue) => {
          if (c === 'reveal') setPhase('reveal');
          if (c === 'exit') finish();
        };
        stage.start();
        setPhase('playing');
        stage.playIntro();
      } catch (e) {
        console.warn('[GREEN PLUG EV] intro scene unavailable', e);
        finish(true);
      }
    })();
    const onResize = () => stage?.resize(window.innerWidth, window.innerHeight);
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && finish(true);
    const onVis = () => stage?.setPaused(document.hidden);
    window.addEventListener('resize', onResize);
    window.addEventListener('keydown', onKey);
    document.addEventListener('visibilitychange', onVis);
    return () => {
      disposed = true;
      window.clearTimeout(guard);
      window.clearTimeout(hardStop);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('keydown', onKey);
      document.removeEventListener('visibilitychange', onVis);
      stage?.dispose();
      stageRef.current = null;
      html.classList.remove('intro-active', 'intro-handoff');
    };
  }, [finish]);

  return (
    <div ref={root} className={`app-intro3d phase-${phase}`} role="dialog" aria-label="GREEN PLUG EV introduction" data-testid="intro" data-phase={phase}>
      <canvas ref={canvas} className="ai3-canvas" aria-hidden="true" />
      <div className="ai3-vignette" aria-hidden="true" />
      {phase === 'loading' && (
        <div className="ai3-loading" aria-live="polite">
          <img src="/app/brand/mark-glossy.webp" alt="" width={96} height={80} />
          <span className="ai3-bar">
            <span style={{ transform: `scaleX(${Math.max(0.06, progress)})` }} />
          </span>
          <span className="ai3-loading-text">Powering up the charging bay…</span>
        </div>
      )}
      <div className="ai3-reveal" aria-hidden={phase !== 'reveal' && phase !== 'exit'}>
        <img className="ai3-mark" src="/app/brand/mark-glossy.webp" alt="" width={120} height={100} />
        <div className="ai3-logo">
          <Logo className="logo" />
          <span className="ai3-sweep" />
        </div>
        <p className="ai3-tag">Find a charger. Book the slot. Plug in.</p>
      </div>
      <div className="ai3-letterbox" aria-hidden="true" />
      <button ref={skipBtn} type="button" className="ai3-skip btn btn-glass btn-sm" onClick={() => finish(true)} data-testid="skip-intro">
        <span className="btn-inner">Skip intro</span>
      </button>
      <span className="ai3-credit">3D car: “Car Concept” © Darmstadt Graphics Group, CC BY 4.0 · scene is illustrative</span>
    </div>
  );
}

/** 2D brand intro used when WebGL is unavailable. */
function IntroLite({ onDone }: { onDone: () => void }) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const html = document.documentElement;
    html.classList.remove('intro-pending');
    html.classList.add('intro-active');
    markSeen();
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      html.classList.remove('intro-active');
      onDone();
    };
    const el = root.current!;
    const tl = gsap.timeline({ onComplete: finish });
    tl.fromTo(el.querySelector('.ai-mark'), { y: 30, scale: 0.7, autoAlpha: 0 }, { y: 0, scale: 1, autoAlpha: 1, duration: 1.0, ease: 'back.out(1.6)' }, 0.1)
      .fromTo(el.querySelector('.ai-word'), { y: 18, autoAlpha: 0 }, { y: 0, autoAlpha: 1, duration: 0.7 }, 0.9)
      .to(el, { autoAlpha: 0, duration: 0.5 }, 2.4);
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && (tl.kill(), finish());
    window.addEventListener('keydown', onKey);
    return () => {
      window.removeEventListener('keydown', onKey);
      tl.kill();
      html.classList.remove('intro-active');
    };
  }, [onDone]);
  return (
    <div className="app-intro" ref={root} role="dialog" aria-label="GREEN PLUG EV introduction" data-testid="intro">
      <div className="ai-stage">
        <img className="ai-mark" src="/app/brand/mark-glossy.webp" alt="" width={200} height={166} />
        <div className="ai-word">
          <Logo className="logo ai-logo" />
        </div>
      </div>
      <button type="button" className="ai-skip btn btn-glass btn-sm" onClick={() => (document.documentElement.classList.remove('intro-active'), onDone())} data-testid="skip-intro">
        <span className="btn-inner">Skip intro</span>
      </button>
    </div>
  );
}
