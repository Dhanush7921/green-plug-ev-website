import { useEffect, useMemo, useState } from 'react';
import { del, get, put } from '../../lib/api';
import { CONFIDENCE_LABELS, COMPAT_LABELS, connectorLabel, rupees } from '../../lib/format';
import { useApi, useDraft } from '../../lib/hooks';
import { Link, useRouter } from '../../lib/router';
import { useSession } from '../../lib/session';
import { useToast } from '../../lib/toast';
import { Icon } from '../../components/Icon';
import { DemoTag, Empty, ErrorNote, Input, Pill, Select } from '../../components/ui';
import { MapView, type MapPoint } from '../../map/MapView';
import { Stage3D } from '../../visual/Stage3D';
import { AvailDot, Skeleton } from '../../visual/Motion';

// Home (AC) charging is the customer offer: AC connector types only (DC is admin-managed, see Admin → Private DC)
const CONNECTOR_FILTERS = ['TYPE2', 'BHARAT_AC001', 'TYPE7_LECCS', 'SOCKET_15A'];
type Filters = { q: string; connectors: string[]; current: '' | 'AC' | 'DC'; minKw: string; maxPrice: string; access: string[]; openNow: boolean; availableOnly: boolean; compatibleOnly: boolean; vehicleId: string; lat: string; lng: string; place: string };
const INITIAL: Filters = { q: '', connectors: [], current: '', minKw: '', maxPrice: '', access: [], openNow: false, availableOnly: false, compatibleOnly: false, vehicleId: '', lat: '', lng: '', place: '' };

export const accessLabel = (a: string) => (a === 'PUBLIC' ? 'Public' : a === 'PRIVATE' ? 'Private' : 'Home charger');
export const stationTone = (s: { operationalStatus: string; freeNow: boolean; openNow: boolean }) => (s.operationalStatus !== 'AVAILABLE' ? 'bad' : s.freeNow ? 'good' : 'warn');

export const availOf = (s: any) => (s.operationalStatus !== 'AVAILABLE' ? 'unavailable' : s.freeNow ? 'available' : 'busy') as 'available' | 'busy' | 'unavailable';

export function StationCard({ s, onToggleSave, selected, onHover, index = 0 }: { s: any; onToggleSave?: (s: any) => void; selected?: boolean; onHover?: () => void; index?: number }) {
  const tone = stationTone(s);
  return (
    <article className={`station-card card ${selected ? 'is-selected' : ''}`} data-gloss data-tilt="2" data-reveal style={{ ['--i' as string]: Math.min(index, 8) }} onMouseEnter={onHover} data-testid="station-card" data-station={s.id}>
      <span className={`station-rail rail-${availOf(s)}`} aria-hidden="true" />
      <Link to={`/stations/${s.id}`} className="station-card-link" aria-label={`${s.name}, ${s.area}`}>
        <div className="station-card-top">
          <div>
            <h3 className="h3 station-name">{s.name}</h3>
            <p className="muted small">
              {s.area}, {s.city}
              {s.distanceKm !== null && s.distanceKm !== undefined && <> · {s.distanceKm} km</>}
            </p>
          </div>
          <div className="station-price">
            <span className="muted small">from</span>
            <strong>
              {rupees(s.minPricePaise)}
              <small>/kWh</small>
            </strong>
          </div>
        </div>
        <div className="chips">
          <span className={`pill pill-${tone}`}>
            <AvailDot state={availOf(s)} />
            {s.operationalStatus !== 'AVAILABLE' ? (s.operationalStatus === 'TEMPORARILY_CLOSED' ? 'Temporarily closed' : 'Unavailable') : s.freeNow ? 'Bookable now' : s.openNow ? 'Busy now' : 'Closed now'}
          </span>
          <span className="pill pill-neutral">
            <Icon name={s.accessType === 'HOME' ? 'house' : s.accessType === 'PRIVATE' ? 'lock' : 'store'} /> {accessLabel(s.accessType)}
          </span>
          {s.maxPowerKw && (
            <span className="pill pill-neutral">
              <Icon name="zap" /> up to {s.maxPowerKw} kW
            </span>
          )}
          {s.compatibility && <Pill tone={s.compatibility === 'COMPATIBLE_VERIFIED' ? 'good' : s.compatibility === 'NEEDS_CONFIRMATION' ? 'warn' : 'bad'}>{COMPAT_LABELS[s.compatibility]}</Pill>}
        </div>
        <div className="connector-chips">
          {[...new Map((s.connectors as any[]).map((c) => [c.standard + c.currentType, c])).values()].map((c: any) => (
            <span key={c.id} className="conn-chip">
              {connectorLabel(c.standard)} <em>{c.currentType}</em>
            </span>
          ))}
        </div>
        <p className="confidence small">
          {s.isDemo && <DemoTag>Simulated</DemoTag>} {CONFIDENCE_LABELS[s.availabilityConfidence]}
          {!s.exactLocation && <> · approximate location</>}
        </p>
      </Link>
      {onToggleSave && (
        <button type="button" className={`fav-btn ${s.saved ? 'is-on' : ''}`} aria-pressed={s.saved} aria-label={s.saved ? `Remove ${s.name} from favourites` : `Save ${s.name} to favourites`} onClick={() => onToggleSave(s)}>
          <Icon name="heart" />
        </button>
      )}
    </article>
  );
}

export function Discover() {
  const { user } = useSession();
  const { navigate } = useRouter();
  const toast = useToast();
  const draft = useDraft<Filters>('discover-filters', INITIAL);
  const f = draft.value;
  const set = draft.update;
  const [showFilters, setShowFilters] = useState(false);
  const [selected, setSelected] = useState<string | null>(null);
  const [places, setPlaces] = useState<any[]>([]);
  const [locating, setLocating] = useState(false);
  const vehicles = useApi<{ vehicles: any[] }>(user ? '/api/me/vehicles' : null);

  const qs = useMemo(() => {
    const p = new URLSearchParams();
    if (f.q.trim()) p.set('q', f.q.trim());
    if (f.connectors.some((c) => CONNECTOR_FILTERS.includes(c))) p.set('connector', f.connectors.filter((c) => CONNECTOR_FILTERS.includes(c)).join(','));
    if (f.minKw) p.set('minKw', f.minKw);
    if (f.maxPrice) p.set('maxPricePaise', String(Math.round(Number(f.maxPrice) * 100)));
    if (f.access.length) p.set('access', f.access.join(','));
    if (f.openNow) p.set('openNow', '1');
    if (f.availableOnly) p.set('availableOnly', '1');
    if (f.compatibleOnly) p.set('compatibleOnly', '1');
    if (f.vehicleId) p.set('vehicleId', f.vehicleId);
    if (f.lat && f.lng) (p.set('lat', f.lat), p.set('lng', f.lng));
    return p.toString();
  }, [f]);
  const [debounced, setDebounced] = useState(qs);
  useEffect(() => {
    const t = setTimeout(() => setDebounced(qs), 250);
    return () => clearTimeout(t);
  }, [qs]);
  const res = useApi<{ stations: any[]; count: number; vehicle: any }>(`/api/stations?${debounced}`, [user?.id]);
  const stations = res.data?.stations || [];

  const points: MapPoint[] = stations.map((s) => ({ id: s.id, lat: s.location.latitude, lng: s.location.longitude, label: rupees(s.minPricePaise), title: `${s.name}, ${rupees(s.minPricePaise)} per kWh, ${s.freeNow ? 'bookable now' : 'not bookable now'}`, tone: stationTone(s), approximate: !s.exactLocation }));
  const toggle = (k: 'connectors' | 'access', v: string) => set({ [k]: f[k].includes(v) ? f[k].filter((x) => x !== v) : [...f[k], v] } as Partial<Filters>);
  const activeCount = [f.connectors.filter((c) => CONNECTOR_FILTERS.includes(c)).length, f.minKw, f.maxPrice, f.access.length, f.openNow, f.availableOnly, f.compatibleOnly].filter(Boolean).length;

  const onToggleSave = async (s: any) => {
    if (!user) return navigate('/signin?next=/');
    try {
      if (s.saved) await del(`/api/me/saved-stations/${s.id}`);
      else await put(`/api/me/saved-stations/${s.id}`);
      res.setData((d) => d && { ...d, stations: d.stations.map((x) => (x.id === s.id ? { ...x, saved: !s.saved } : x)) });
      toast(s.saved ? 'Removed from favourites' : 'Saved to favourites', 'good');
    } catch (e) {
      toast((e as Error).message, 'bad');
    }
  };
  const searchPlace = async (q: string) => {
    set({ place: q });
    if (q.trim().length < 2) return setPlaces([]);
    const r = await get(`/api/geo/search?q=${encodeURIComponent(q)}`).catch(() => ({ places: [] }));
    setPlaces(r.places);
  };
  const nearMe = () => {
    if (!navigator.geolocation) return toast('Location is not available in this browser.', 'bad');
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (p) => {
        setLocating(false);
        set({ lat: p.coords.latitude.toFixed(5), lng: p.coords.longitude.toFixed(5), place: 'My location' });
      },
      () => {
        setLocating(false);
        toast('Location permission was not granted. Search for a place instead.', 'info');
      },
      { timeout: 8000 },
    );
  };

  return (
    <div className="discover">
      <section className="driver-hero" data-testid="driver-hero">
        <div className="dh-copy">
          <span className="kicker">EV Driver · {user ? `Hi ${user.fullName.split(' ')[0]}` : 'Welcome'}</span>
          <h1 className="h1 dh-title">
            Charge where <span className="ink-gradient">you're going.</span>
          </h1>
          <p className="lede dh-lede">Compatible chargers, honest per-kWh prices and bookable slots — on a map that never pretends availability is live.</p>
          <div className="dh-stats">
            <span>
              <strong>{stations.length || '—'}</strong> stations
            </span>
            <span>
              <AvailDot state="available" /> <strong>{stations.filter((x) => x.freeNow).length}</strong> bookable now
            </span>
            <span>
              <strong>{stations.length ? Math.max(...stations.map((x) => x.maxPowerKw || 0)) : '—'}</strong> kW max
            </span>
            <DemoTag>Simulated availability</DemoTag>
          </div>
          <div className="dh-quick" role="group" aria-label="Quick filters">
            <button type="button" className={`chip-btn ${f.connectors.includes('TYPE2') ? 'is-on' : ''}`} aria-pressed={f.connectors.includes('TYPE2')} onClick={() => toggle('connectors', 'TYPE2')}>
              <Icon name="plug" /> Type 2 AC
            </button>
            <button type="button" className={`chip-btn ${f.openNow ? 'is-on' : ''}`} aria-pressed={f.openNow} onClick={() => set({ openNow: !f.openNow })}>
              <Icon name="clock" /> Open now
            </button>
            <button type="button" className={`chip-btn ${f.access.includes('HOME') ? 'is-on' : ''}`} aria-pressed={f.access.includes('HOME')} onClick={() => toggle('access', 'HOME')}>
              <Icon name="house" /> Home chargers
            </button>
          </div>
        </div>
        <Stage3D mode="hero" className="dh-stage" label="3D scene: an electric car charging at a GREEN PLUG EV station" />
      </section>

      <div className="search-bar card glass">
        <label className="search-field">
          <Icon name="search" />
          <span className="sr-only">Search stations</span>
          <input className="input" placeholder="Station, area, city or facility (e.g. café)" value={f.q} onChange={(e) => set({ q: e.target.value })} data-testid="search-input" />
        </label>
        <div className="search-field place-field">
          <Icon name="navigation" />
          <input className="input" placeholder="Near a place…" value={f.place} onChange={(e) => searchPlace(e.target.value)} aria-label="Sort by distance from a place" />
          {places.length > 0 && (
            <ul className="suggest glass">
              {places.map((p) => (
                <li key={p.label}>
                  <button type="button" onClick={() => (set({ lat: String(p.latitude), lng: String(p.longitude), place: p.label }), setPlaces([]))}>
                    {p.label} <span className="muted small">{p.source === 'demo-gazetteer' ? 'demo geocoder' : ''}</span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
        <button type="button" className="btn btn-glass btn-sm" onClick={nearMe} data-gloss>
          <span className="btn-inner">
            <Icon name={locating ? 'loader-circle' : 'locate-fixed'} className={`icon ${locating ? 'spin' : ''}`} /> Near me
          </span>
        </button>
        <button type="button" className={`btn btn-sm ${showFilters ? 'btn-primary' : 'btn-glass'}`} aria-expanded={showFilters} onClick={() => setShowFilters(!showFilters)} data-testid="filters-toggle" data-gloss>
          <span className="btn-inner">
            <Icon name="sliders-horizontal" /> Filters{activeCount ? ` (${activeCount})` : ''}
          </span>
        </button>
      </div>

      {showFilters && (
        <div className="filters card" data-testid="filters">
          <fieldset>
            <legend>Connector</legend>
            <div className="chip-row">
              {CONNECTOR_FILTERS.map((c) => (
                <button key={c} type="button" className={`chip-btn ${f.connectors.includes(c) ? 'is-on' : ''}`} aria-pressed={f.connectors.includes(c)} onClick={() => toggle('connectors', c)}>
                  {connectorLabel(c)}
                </button>
              ))}
            </div>
          </fieldset>
          <fieldset>
            <legend>Access</legend>
            <div className="chip-row">
              {['PUBLIC', 'PRIVATE', 'HOME'].map((a) => (
                <button key={a} type="button" className={`chip-btn ${f.access.includes(a) ? 'is-on' : ''}`} aria-pressed={f.access.includes(a)} onClick={() => toggle('access', a)}>
                  {accessLabel(a)}
                </button>
              ))}
            </div>
          </fieldset>
          <div className="filters-row">
            <label>
              <span>Min power</span>
              <Select value={f.minKw} onChange={(e) => set({ minKw: e.target.value })} aria-label="Minimum charging power">
                <option value="">Any</option>
                {[3, 7, 11, 22].map((k) => (
                  <option key={k} value={k}>
                    {k}+ kW
                  </option>
                ))}
              </Select>
            </label>
            <label>
              <span>Max ₹/kWh</span>
              <Input type="number" min={1} step={0.5} value={f.maxPrice} onChange={(e) => set({ maxPrice: e.target.value })} placeholder="Any" aria-label="Maximum price per kWh in rupees" />
            </label>
            {user && (
              <label>
                <span>My vehicle</span>
                <Select value={f.vehicleId} onChange={(e) => set({ vehicleId: e.target.value })} aria-label="Vehicle for compatibility">
                  <option value="">Default vehicle</option>
                  {vehicles.data?.vehicles.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.nickname}
                    </option>
                  ))}
                </Select>
              </label>
            )}
          </div>
          <div className="filters-row toggles">
            <label className="check">
              <input type="checkbox" checked={f.openNow} onChange={(e) => set({ openNow: e.target.checked })} /> <span>Open now</span>
            </label>
            <label className="check">
              <input type="checkbox" checked={f.availableOnly} onChange={(e) => set({ availableOnly: e.target.checked })} /> <span>Bookable now</span>
            </label>
            {user && (
              <label className="check">
                <input type="checkbox" checked={f.compatibleOnly} onChange={(e) => set({ compatibleOnly: e.target.checked })} /> <span>Compatible with my vehicle</span>
              </label>
            )}
            <button type="button" className="link-btn" onClick={() => (draft.clear(), draft.setValue(INITIAL))}>
              Reset filters
            </button>
          </div>
        </div>
      )}

      <div className="discover-grid">
        <div className="discover-map">
          <MapView points={points} selectedId={selected} onSelect={(id) => setSelected(id)} height="100%" />
          {selected && (() => {
            const s = stations.find((x) => x.id === selected);
            return s ? (
              <div className="map-pop glass" key={s.id} data-testid="station-preview">
                <button type="button" className="icon-btn map-pop-close" aria-label="Close preview" onClick={() => setSelected(null)}>
                  <Icon name="x" />
                </button>
                <span className="kicker">{accessLabel(s.accessType)} · {s.area}</span>
                <strong className="map-pop-title">{s.name}</strong>
                <div className="map-pop-facts">
                  <span>
                    <b>{rupees(s.minPricePaise)}</b>/kWh
                  </span>
                  <span>
                    <b>{s.maxPowerKw}</b> kW
                  </span>
                  {s.distanceKm !== null && s.distanceKm !== undefined && (
                    <span>
                      <b>{s.distanceKm}</b> km
                    </span>
                  )}
                </div>
                <AvailDot state={availOf(s)} label={availOf(s) === 'available' ? 'Bookable now' : availOf(s) === 'busy' ? 'Busy or closed now' : 'Unavailable'} />
                <div className="connector-chips">
                  {[...new Set((s.connectors as any[]).map((c) => `${connectorLabel(c.standard)} ${c.currentType}`))].map((c) => (
                    <span key={c} className="conn-chip">
                      {c}
                    </span>
                  ))}
                </div>
                <Link to={`/stations/${s.id}`} className="btn btn-primary btn-sm" data-gloss>
                  <span className="btn-inner">
                    View & book <Icon name="arrow-right" />
                  </span>
                </Link>
              </div>
            ) : null;
          })()}
        </div>
        <div className="discover-list" aria-live="polite">
          <div className="list-head">
            <strong data-testid="result-count">
              {res.loading && !res.data ? 'Searching…' : `${stations.length} station${stations.length === 1 ? '' : 's'}`}
            </strong>
            {f.place && f.lat && <span className="muted small">sorted by distance from {f.place}</span>}
            {res.data?.vehicle && <span className="muted small">compatibility for {res.data.vehicle.nickname}</span>}
          </div>
          <ErrorNote error={res.error} onRetry={res.reload} />
          {res.loading && !res.data && <Skeleton rows={4} />}
          {res.data && !stations.length && (
            <Empty icon="search" title="No stations match these filters">
              Try removing a filter or searching a different area.
            </Empty>
          )}
          {stations.map((s, i) => (
            <StationCard key={s.id} s={s} index={i} selected={selected === s.id} onHover={() => setSelected(s.id)} onToggleSave={onToggleSave} />
          ))}
        </div>
      </div>
    </div>
  );
}
