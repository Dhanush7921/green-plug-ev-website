// Runs before the app bundle (external file so the CSP needs no 'unsafe-inline'): applies the saved theme and
// decides whether the cinematic intro plays — first visit in this browser, on an entry page only, never with
// reduced motion. `?intro` forces it (e.g. for demos), `?nointro` suppresses it.
(function () {
  var d = document.documentElement;
  try {
    var t = localStorage.getItem('gpev-theme');
    if (t !== 'light' && t !== 'dark') t = matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    d.setAttribute('data-theme', t);
    var p = location.pathname.replace(/\/+$/, '');
    var entry = p === '/app' || p === '/app/welcome' || p === '/app/partner' || p === '/app/admin';
    var forced = /[?&]intro(=|&|$)/.test(location.search);
    var seen = localStorage.getItem('gpev-app-intro-seen') === '1';
    if (!matchMedia('(prefers-reduced-motion: reduce)').matches && !/[?&]nointro/.test(location.search) && (forced || (entry && !seen))) d.classList.add('intro-pending');
  } catch (e) {}
})();
