-- 002: Home (AC) charging is the customer offer. Private DC fast chargers are onboarded by administrators only and
-- stay hidden from customers until the owner has accepted the partnership/commission deal and an admin publishes them.
-- Backward-compatible: existing rows keep working (new columns are nullable / defaulted).

-- An admin can record a private DC owner who has no app account yet.
ALTER TABLE partners ALTER COLUMN owner_user_id DROP NOT NULL;
ALTER TABLE partners ADD COLUMN managed_by_admin boolean NOT NULL DEFAULT false;
ALTER TABLE partners ADD CONSTRAINT partners_owner_or_admin_managed CHECK (owner_user_id IS NOT NULL OR managed_by_admin);

-- Deal workflow for admin-managed private DC stations: PENDING → DEAL_ACCEPTED → PUBLISHED (NULL = not a DC deal station).
ALTER TABLE stations ADD COLUMN dc_deal_status text CHECK (dc_deal_status IN ('PENDING', 'DEAL_ACCEPTED', 'PUBLISHED'));
ALTER TABLE stations ADD COLUMN dc_deal_note text CHECK (dc_deal_note IS NULL OR length(dc_deal_note) <= 500);
ALTER TABLE stations ADD COLUMN dc_deal_updated_at timestamptz;
-- database-level guard: a DC deal station is listed (APPROVED) if and only if it is PUBLISHED
ALTER TABLE stations ADD CONSTRAINT stations_dc_listed_only_when_published
  CHECK (dc_deal_status IS NULL OR ((dc_deal_status = 'PUBLISHED') = (listing_status = 'APPROVED')));
CREATE INDEX stations_dc_deal_idx ON stations (dc_deal_status) WHERE dc_deal_status IS NOT NULL;
