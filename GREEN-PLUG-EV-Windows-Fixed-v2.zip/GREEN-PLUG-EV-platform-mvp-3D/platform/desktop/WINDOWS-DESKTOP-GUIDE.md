# GREEN PLUG EV — Windows Desktop Installer

This package wraps the existing `platform/` React/Three.js UI and Node/TypeScript API in Electron. It does **not** replace the backend, database migrations, authentication, role authorization or booking logic.

## What gets installed

- GREEN PLUG EV desktop shell and app icon.
- Existing built React frontend, including the real-time 3D charging scene and all Driver, Station Partner and Admin workspaces.
- Existing bundled Node/TypeScript API and PostgreSQL migrations.
- Local configuration and logs under the current Windows user's Electron app-data folder.

## System requirement

PostgreSQL 14+ is required. PostgreSQL is not bundled into this installer. The installer also does not deploy a server or turn test payments into real payments. Use a local development database for this desktop MVP.

## Build on Windows 10/11

1. Install Node.js 22 or newer.
2. Install PostgreSQL 16, including the `citext` and `btree_gist` extensions available in the standard distribution.
3. Extract the project ZIP and open PowerShell in `platform/`.
4. Install packages:

   ```powershell
   npm.cmd install
   ```

5. Build the real frontend and backend bundle:

   ```powershell
   npm.cmd run build
   ```

6. Build a Windows x64 NSIS installer by running this helper from `platform/`:

   ```powershell
   powershell -NoProfile -ExecutionPolicy Bypass -File .\desktop\build-windows.ps1
   ```

   Or run `npm.cmd run desktop:build:win` manually. The helper installs dependencies if needed, builds the app, and opens the output folder.

7. The installer is written to `platform/release/GREEN-PLUG-EV-Setup-0.1.0-x64.exe` (version may change).

## First launch

The desktop app creates a per-user configuration file on first launch, runs idempotent database setup/migrations and seeds clearly labelled local demo data if the database is empty. Default connection string:

```text
postgres://postgres:devpassword@127.0.0.1:5433/gpev_dev
```

Change the connection string to match your PostgreSQL setup in the local configuration file accessible from **GREEN PLUG EV → Open local configuration** in the application menu. The password must belong to a PostgreSQL role allowed to create the app database on first launch; alternatively pre-create `gpev_dev`, grant the required rights and retain a matching connection string.

Demo accounts (local only):

- EV Driver: `asha@greenplug.test` / `DriverDemo2026`
- Station Partner: `partner@greenplug.test` / `PartnerDemo2026`
- Admin: `admin@greenplug.test` / `AdminDemo2026`

The desktop package forces a local demo profile and test checkout. It does not collect live payments. Real map tiles, station telemetry, OTP/messaging providers and payout transfers remain external integrations.

## Data and logs

- Configuration: opened through **GREEN PLUG EV → Open local configuration**.
- App logs: **GREEN PLUG EV → Open server log** (server output) and the `logs` folder in the app-data directory.
- Photos/session data are written under the user's app-data directory, not the read-only installation folder.
- Uninstalling the application does not intentionally delete PostgreSQL data or user configuration.

## Build caveats

This is an unsigned development installer unless a Windows code-signing certificate is configured. Windows SmartScreen may show an unknown-publisher warning. Do not distribute widely without a signed release, security review, installer testing and production service configuration.

The Linux build environment does not include Wine or Windows installer tooling, so a Windows `.exe` cannot be honestly claimed as built in that environment. Build the installer on Windows using the command above, or use a supported Wine-enabled build environment.
