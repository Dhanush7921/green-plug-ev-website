$ErrorActionPreference = 'Stop'
$ProjectDir = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Push-Location $ProjectDir
try {
    Write-Host 'GREEN PLUG EV — Windows desktop installer build' -ForegroundColor Green
    $nodeVersion = (& node -p "process.versions.node").Trim()
    if ($LASTEXITCODE -ne 0) { throw 'Node.js was not found. Install Node.js 22 or newer from https://nodejs.org.' }
    $major = [int]($nodeVersion.Split('.')[0])
    if ($major -lt 22) { throw "Node.js 22+ is required; found $nodeVersion." }
    Write-Host "Node.js $nodeVersion" -ForegroundColor DarkGreen
    if (-not (Test-Path (Join-Path $ProjectDir 'node_modules'))) {
        Write-Host 'Installing dependencies…' -ForegroundColor Cyan
        & npm.cmd install
        if ($LASTEXITCODE -ne 0) { throw 'npm install failed. Check network/package registry access and rerun this script.' }
    }
    Write-Host 'Building installer (frontend, API and NSIS package)…' -ForegroundColor Cyan
    & npm.cmd run desktop:build:win
    if ($LASTEXITCODE -ne 0) { throw 'Installer build failed; review the error output above.' }
    $package = Get-Content (Join-Path $ProjectDir 'package.json') -Raw | ConvertFrom-Json
    $installer = Join-Path $ProjectDir ("release\GREEN-PLUG-EV-Setup-{0}-x64.exe" -f $package.version)
    if (-not (Test-Path $installer)) {
        $found = Get-ChildItem (Join-Path $ProjectDir 'release') -Filter '*.exe' -ErrorAction SilentlyContinue
        if ($found) { $installer = $found[0].FullName } else { throw 'Build returned success but the expected installer was not found in platform\release.' }
    }
    Write-Host "`nINSTALLER READY: $installer" -ForegroundColor Green
    Write-Host 'The app requires a running PostgreSQL service; read desktop\WINDOWS-DESKTOP-GUIDE.md before first launch.'
    Start-Process explorer.exe -ArgumentList "/select,`"$installer`""
} finally {
    Pop-Location
}
