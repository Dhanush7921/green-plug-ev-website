'use strict';

const { app, BrowserWindow, dialog, shell, Menu, nativeImage, session } = require('electron');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const net = require('node:net');
const http = require('node:http');

const APP_ID = 'in.greenplugev.platform';
const PRODUCT_NAME = 'GREEN PLUG EV';
app.setName(PRODUCT_NAME);
app.setAppUserModelId(APP_ID);

const appRoot = app.isPackaged ? app.getAppPath() : path.resolve(__dirname, '..');
const userData = app.getPath('userData');
const configPath = path.join(userData, 'greenplug.env');
const logDir = path.join(userData, 'logs');
const logPath = path.join(logDir, 'desktop.log');
const serverLogPath = path.join(logDir, 'server.log');
const serverEntry = path.join(appRoot, 'dist', 'server.mjs');
const cliEntry = path.join(appRoot, 'dist', 'cli.mjs');
const migrationDir = path.join(appRoot, 'database', 'migrations');
const webDir = path.join(appRoot, 'dist', 'web');
let serverProcess = null;
let mainWindow = null;
let splashWindow = null;
let appPort = null;
let stopping = false;

function log(message) {
  const line = `[${new Date().toISOString()}] ${message}\n`;
  try { fs.mkdirSync(logDir, { recursive: true }); fs.appendFileSync(logPath, line); } catch {}
}

function parseEnvFile(text) {
  const out = {};
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const match = line.match(/^([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
    if (!match) continue;
    let value = match[2].trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    out[match[1]] = value;
  }
  return out;
}

function ensureUserConfig() {
  fs.mkdirSync(userData, { recursive: true });
  fs.mkdirSync(logDir, { recursive: true });
  const storageDir = path.join(userData, 'storage');
  fs.mkdirSync(storageDir, { recursive: true });
  if (!fs.existsSync(configPath)) {
    const starter = [
      '# GREEN PLUG EV desktop local configuration. Keep this file private.',
      '# Edit DATABASE_URL to match your installed PostgreSQL service.',
      'NODE_ENV=development',
      'HOST=127.0.0.1',
      'DATABASE_URL=postgres://postgres:devpassword@127.0.0.1:5433/gpev_dev',
      'DEMO_MODE=true',
      'PAYMENT_PROVIDER=test',
      'PAYMENTS_LIVE_ENABLED=false',
      'PAYMENT_WEBHOOK_SECRET=local-test-webhook-secret-change-me',
      'MAPS_PROVIDER=demo',
      'EMAIL_PROVIDER=demo',
      'SMS_PROVIDER=demo',
      'PUSH_PROVIDER=demo',
      'LOG_REQUESTS=0',
      'SEED_ADMIN_PASSWORD=',
      'SEED_DEMO_PASSWORD=',
      ''
    ].join('\r\n');
    fs.writeFileSync(configPath, starter, { encoding: 'utf8', flag: 'wx' });
  }
  const fileVars = parseEnvFile(fs.readFileSync(configPath, 'utf8'));
  // Explicit inherited process variables take precedence over user config, except desktop-owned runtime values.
  const base = { ...fileVars, ...process.env };
  base.NODE_ENV = 'development'; // local demo profile; the app has separate production safeguards.
  base.HOST = '127.0.0.1';
  base.COOKIE_SECURE = 'false';
  base.DEMO_MODE = fileVars.DEMO_MODE || process.env.DEMO_MODE || 'true';
  base.PAYMENT_PROVIDER = fileVars.PAYMENT_PROVIDER || process.env.PAYMENT_PROVIDER || 'test';
  base.PAYMENTS_LIVE_ENABLED = 'false';
  base.STORAGE_DIR = storageDir;
  base.MIGRATIONS_DIR = migrationDir;
  base.WEB_DIR = webDir;
  return base;
}

function getFreePort() {
  return new Promise((resolve, reject) => {
    const probe = net.createServer();
    probe.once('error', reject);
    probe.listen(0, '127.0.0.1', () => {
      const address = probe.address();
      const port = typeof address === 'object' && address ? address.port : 0;
      probe.close((err) => err ? reject(err) : resolve(port));
    });
  });
}

function setSplashStatus(message, detail = '') {
  if (!splashWindow || splashWindow.isDestroyed()) return;
  const safe = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c]));
  splashWindow.webContents.executeJavaScript(`window.setStatus(${JSON.stringify(safe(message))}, ${JSON.stringify(safe(detail))})`).catch(() => {});
}

function runBundledNode(entry, args, env, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(entry)) return reject(new Error(`Required app file is missing: ${entry}`));
    // Electron's embedded Node runtime avoids requiring a separate Node.js install on user machines.
    const childEnv = { ...env, ELECTRON_RUN_AS_NODE: '1', ELECTRON_NO_ATTACH_CONSOLE: '1' };
    const child = spawn(process.execPath, [entry, ...args], {
      cwd: appRoot,
      env: childEnv,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let stdout = '';
    let stderr = '';
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error(`Timed out running ${path.basename(entry)}.\n${stderr || stdout}`));
    }, timeoutMs);
    child.stdout.on('data', (chunk) => { stdout += chunk.toString(); });
    child.stderr.on('data', (chunk) => { stderr += chunk.toString(); });
    child.once('error', (err) => { clearTimeout(timer); reject(err); });
    child.once('close', (code) => {
      clearTimeout(timer);
      if (code === 0) resolve({ stdout, stderr });
      else reject(new Error(`${path.basename(entry)} exited with code ${code}.\n${stderr || stdout}`));
    });
  });
}

function startApi(env) {
  return new Promise((resolve, reject) => {
    if (!fs.existsSync(serverEntry)) return reject(new Error(`Built server was not found: ${serverEntry}\nBuild the platform first.`));
    const childEnv = { ...env, ELECTRON_RUN_AS_NODE: '1', ELECTRON_NO_ATTACH_CONSOLE: '1' };
    const child = spawn(process.execPath, [serverEntry], {
      cwd: appRoot,
      env: childEnv,
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    serverProcess = child;
    const out = fs.createWriteStream(serverLogPath, { flags: 'a' });
    child.stdout.pipe(out, { end: false });
    child.stderr.pipe(out, { end: false });
    child.once('error', reject);
    child.once('exit', (code, signal) => {
      if (!stopping && mainWindow && !mainWindow.isDestroyed()) {
        dialog.showErrorBox(PRODUCT_NAME, `The local API stopped (${code ?? signal}).\n\nLog: ${serverLogPath}`);
      }
    });
    resolve(child);
  });
}

function waitForHealth(port, timeoutMs = 25000) {
  const started = Date.now();
  return new Promise((resolve, reject) => {
    const check = () => {
      if (stopping) return reject(new Error('Application is closing.'));
      const req = http.get({ hostname: '127.0.0.1', port, path: '/api/health', timeout: 1200 }, (res) => {
        let body = '';
        res.setEncoding('utf8');
        res.on('data', (c) => body += c);
        res.on('end', () => {
          if (res.statusCode === 200) {
            try {
              const data = JSON.parse(body);
              if (data.ok && data.database === 'up') return resolve(data);
            } catch {}
          }
          if (Date.now() - started > timeoutMs) return reject(new Error(`The app server did not become ready. Health response: ${body}`));
          setTimeout(check, 700);
        });
      });
      req.on('error', () => {
        if (Date.now() - started > timeoutMs) return reject(new Error('The local server did not respond. See server.log in the app data folder.'));
        setTimeout(check, 700);
      });
      req.on('timeout', () => req.destroy());
    };
    check();
  });
}

function createSplash() {
  splashWindow = new BrowserWindow({
    width: 560, height: 390, resizable: false, show: false, frame: false,
    backgroundColor: '#07130f', icon: path.join(appRoot, 'desktop', 'assets', 'app-icon.ico'),
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true },
  });
  splashWindow.loadFile(path.join(__dirname, 'splash.html'));
  splashWindow.once('ready-to-show', () => splashWindow && splashWindow.show());
  return splashWindow;
}

function createMainWindow(url) {
  mainWindow = new BrowserWindow({
    width: 1480,
    height: 940,
    minWidth: 960,
    minHeight: 680,
    show: false,
    title: PRODUCT_NAME,
    backgroundColor: '#07130f',
    icon: path.join(appRoot, 'desktop', 'assets', 'app-icon.ico'),
    autoHideMenuBar: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      spellcheck: false,
    },
  });
  mainWindow.webContents.setWindowOpenHandler(({ url: target }) => {
    try { const u = new URL(target); if (u.protocol === 'https:' || u.protocol === 'mailto:') shell.openExternal(target); } catch {}
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event, target) => {
    const allowed = `http://127.0.0.1:${appPort}`;
    if (!target.startsWith(allowed + '/') && target !== allowed) {
      event.preventDefault();
      try { const u = new URL(target); if (u.protocol === 'https:' || u.protocol === 'mailto:') shell.openExternal(target); } catch {}
    }
  });
  mainWindow.webContents.on('render-process-gone', (_event, details) => log(`renderer gone: ${JSON.stringify(details)}`));
  mainWindow.webContents.on('console-message', (_event, level, message, line, sourceId) => {
    if (level >= 2) log(`renderer console error: ${message} (${sourceId}:${line})`);
  });
  mainWindow.loadURL(url);
  mainWindow.once('ready-to-show', () => { if (mainWindow) mainWindow.show(); });
  if (process.env.GREENPLUG_DESKTOP_DEVTOOLS === '1') mainWindow.webContents.openDevTools();
  mainWindow.on('closed', () => { mainWindow = null; });
  return mainWindow;
}

function installMenu() {
  const template = [
    { label: 'GREEN PLUG EV', submenu: [
      { label: 'Open local configuration', click: () => shell.openPath(configPath) },
      { label: 'Open application data folder', click: () => shell.openPath(userData) },
      { label: 'Open server log', click: () => shell.openPath(serverLogPath) },
      { type: 'separator' },
      { label: 'Quit', accelerator: 'Alt+F4', click: () => app.quit() },
    ] },
    { label: 'View', submenu: [
      { role: 'reload' },
      { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' },
      { type: 'separator' }, { role: 'togglefullscreen' },
    ] },
    { label: 'Help', submenu: [
      { label: 'Local setup guide', click: () => shell.openPath(path.join(appRoot, 'desktop', 'WINDOWS-DESKTOP-GUIDE.md')) },
      { label: 'Integration checklist', click: () => shell.openPath(path.join(appRoot, 'INTEGRATIONS.md')) },
    ] },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

async function boot() {
  ensureUserConfig();
  installMenu();
  createSplash();
  const env = ensureUserConfig();
  try {
    if (!fs.existsSync(webDir) || !fs.existsSync(path.join(webDir, 'index.html'))) {
      throw new Error('The frontend build is missing. Build the platform with npm run build before packaging.');
    }
    if (!fs.existsSync(migrationDir)) throw new Error(`Database migrations are missing: ${migrationDir}`);
    setSplashStatus('Connecting to PostgreSQL', 'Checking the local database and applying safe, additive migrations…');
    appPort = await getFreePort();
    env.PORT = String(appPort);
    env.APP_ORIGIN = `http://127.0.0.1:${appPort}`;
    // Setup is idempotent: migrations are only applied once; demo seed is skipped if users already exist.
    await runBundledNode(cliEntry, ['setup'], env, 120000);
    setSplashStatus('Starting the platform', 'Launching the local API and cinematic EV experience…');
    await startApi(env);
    await waitForHealth(appPort);
    const url = `http://127.0.0.1:${appPort}/app/`;
    log(`ready at ${url}; database URL host is local/configured; demoMode=${env.DEMO_MODE}`);
    if (splashWindow && !splashWindow.isDestroyed()) splashWindow.close();
    splashWindow = null;
    createMainWindow(url);
  } catch (err) {
    const message = err && err.message ? err.message : String(err);
    log(`startup failure: ${message}`);
    if (splashWindow && !splashWindow.isDestroyed()) splashWindow.close();
    splashWindow = null;
    const buttons = ['Open configuration', 'Open setup guide', 'Show log folder', 'Quit'];
    const result = await dialog.showMessageBox({
      type: 'error',
      title: `${PRODUCT_NAME} could not start`,
      message: 'The desktop app could not connect to the database or start its local services.',
      detail: `${message}\n\n1. Start PostgreSQL.\n2. Check DATABASE_URL in the local config file.\n3. See desktop.log and server.log in the app data folder.\n\nConfig: ${configPath}`,
      buttons,
      defaultId: 0,
      cancelId: 3,
      noLink: true,
    });
    if (result.response === 0) await shell.openPath(configPath);
    if (result.response === 1) await shell.openPath(path.join(appRoot, 'desktop', 'WINDOWS-DESKTOP-GUIDE.md'));
    if (result.response === 2) await shell.openPath(logDir);
    app.quit();
  }
}

app.whenReady().then(() => {
  // Allow only the geolocation permission; camera and microphone remain denied.
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => callback(permission === 'geolocation'));
  boot().catch((err) => {
    log(`unhandled boot error: ${err?.stack || err}`);
    dialog.showErrorBox(PRODUCT_NAME, String(err?.message || err));
    app.quit();
  });
});

app.on('before-quit', () => {
  stopping = true;
  if (serverProcess && !serverProcess.killed) {
    try { serverProcess.kill(); } catch {}
  }
});

app.on('window-all-closed', () => app.quit());
