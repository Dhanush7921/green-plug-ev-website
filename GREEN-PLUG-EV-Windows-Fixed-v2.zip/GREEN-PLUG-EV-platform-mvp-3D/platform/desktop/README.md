# GREEN PLUG EV desktop wrapper

Electron main process for the existing `platform/` app. It starts the bundled API with Electron's embedded Node runtime, applies database migrations, waits for `/api/health`, then opens the existing `/app/` UI. PostgreSQL remains a required service and is not bundled.

For Windows installer commands and first-run configuration, read [`WINDOWS-DESKTOP-GUIDE.md`](WINDOWS-DESKTOP-GUIDE.md).

Quick build on Windows: from `platform/`, run `powershell -NoProfile -ExecutionPolicy Bypass -File .\desktop\build-windows.ps1`.
