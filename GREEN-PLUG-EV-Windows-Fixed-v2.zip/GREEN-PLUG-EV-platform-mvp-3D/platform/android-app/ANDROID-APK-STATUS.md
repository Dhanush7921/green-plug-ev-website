# APK build status

The Android wrapper source and Windows APK build script have been prepared. An APK has **not** been generated in the authoring environment because it has no Android SDK, Android build-tools, or Gradle installation, and package/distribution downloads timed out. Do not treat the source ZIP as an APK.

To produce the installable debug APK, install Android Studio + SDK Platform 35 + Build-Tools 35.x, then run `build-apk.ps1` in this folder on Windows. It will download Gradle 8.10.2 and compile `assembleDebug`. See `BUILD-ANDROID-WINDOWS.md`.

Expected output after a successful local build:

`platform/android-app/dist/GREEN-PLUG-EV-debug.apk`

The APK is a native WebView client that connects to the configured GREEN PLUG EV server. PostgreSQL and the API are still server-side; no backend secrets are included in the app.
