package in.greenplugev.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.net.URI;
import java.util.Locale;

/**
 * Thin Android shell for the GREEN PLUG EV web platform.
 * The server continues to own authentication, permissions, bookings and PostgreSQL.
 */
public final class MainActivity extends Activity {
    private static final String PREFS = "green_plug_ev_settings";
    private static final String KEY_SERVER_URL = "server_url";
    private static final String EMULATOR_DEFAULT = "http://10.0.2.2:8080/app/";
    private static final int LOCATION_PERMISSION_REQUEST = 704;

    private SharedPreferences prefs;
    private WebView webView;
    private ProgressBar progress;
    private TextView connectivityHint;
    private String appUrl = EMULATOR_DEFAULT;
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;
    private boolean errorDialogShowing = false;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(8, 38, 29));
        window.setNavigationBarColor(Color.rgb(6, 29, 22));
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        appUrl = prefs.getString(KEY_SERVER_URL, "");
        buildShell();
        configureWebView();

        if (appUrl.isEmpty()) {
            showServerDialog(true);
        } else {
            loadApp();
        }
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(8, 38, 29));
        // Android 15 enforces edge-to-edge for apps targeting API 35; keep the native bar clear of system UI.
        if (Build.VERSION.SDK_INT >= 35) {
            root.setPadding(0, systemBarHeight("status_bar_height"), 0, systemBarHeight("navigation_bar_height"));
        }

        LinearLayout toolbar = new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setOrientation(LinearLayout.HORIZONTAL);
        toolbar.setPadding(dp(16), 0, dp(8), 0);
        toolbar.setBackgroundColor(Color.rgb(8, 38, 29));

        LinearLayout titleColumn = new LinearLayout(this);
        titleColumn.setOrientation(LinearLayout.VERTICAL);
        titleColumn.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = new TextView(this);
        title.setText("GREEN PLUG EV");
        title.setTextColor(Color.WHITE);
        title.setTextSize(15);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView subtitle = new TextView(this);
        subtitle.setText("EV CHARGING PLATFORM");
        subtitle.setTextColor(Color.rgb(151, 218, 185));
        subtitle.setTextSize(9);
        subtitle.setLetterSpacing(0.12f);
        titleColumn.addView(title);
        titleColumn.addView(subtitle);
        toolbar.addView(titleColumn, new LinearLayout.LayoutParams(0, -1, 1));

        TextView menuButton = new TextView(this);
        menuButton.setText("⋮");
        menuButton.setTextColor(Color.WHITE);
        menuButton.setTextSize(28);
        menuButton.setGravity(Gravity.CENTER);
        menuButton.setContentDescription("App options");
        menuButton.setPadding(dp(12), 0, dp(12), 0);
        menuButton.setOnClickListener(this::showMenu);
        toolbar.addView(menuButton, new LinearLayout.LayoutParams(dp(48), -1));
        root.addView(toolbar, new LinearLayout.LayoutParams(-1, dp(52)));

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgress(0);
        progress.setIndeterminate(false);
        if (Build.VERSION.SDK_INT >= 21) {
            progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(53, 199, 139)));
            progress.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(220, 232, 224)));
        }
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(3)));

        FrameLayout webHost = new FrameLayout(this);
        webView = new WebView(this);
        webHost.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        connectivityHint = new TextView(this);
        connectivityHint.setTextColor(Color.rgb(79, 100, 88));
        connectivityHint.setTextSize(12);
        connectivityHint.setGravity(Gravity.CENTER);
        connectivityHint.setPadding(dp(24), dp(12), dp(24), dp(12));
        connectivityHint.setText("Connecting to your GREEN PLUG EV server…");
        connectivityHint.setBackgroundColor(Color.rgb(246, 248, 245));
        connectivityHint.setVisibility(View.GONE);
        webHost.addView(connectivityHint, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));
        root.addView(webHost, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setLoadsImagesAutomatically(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(webView, false);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (isInternalUrl(u)) return false;
                openExternal(u);
                return true;
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progress.setVisibility(View.VISIBLE);
                progress.setProgress(8);
                connectivityHint.setVisibility(View.GONE);
                errorDialogShowing = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setProgress(100);
                progress.postDelayed(() -> progress.setVisibility(View.GONE), 180);
                CookieManager.getInstance().flush();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showConnectionError();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setVisibility(newProgress >= 100 ? View.GONE : View.VISIBLE);
                progress.setProgress(newProgress);
            }

            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                    callback.invoke(origin, isSameHost(origin), false);
                    return;
                }
                pendingGeoCallback = callback;
                pendingGeoOrigin = origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_PERMISSION_REQUEST);
            }
        });
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setBackgroundColor(Color.rgb(246, 248, 245));
    }

    private void showMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Change server URL").setOnMenuItemClickListener(item -> { showServerDialog(false); return true; });
        menu.getMenu().add("Reload app").setOnMenuItemClickListener(item -> { loadApp(); return true; });
        menu.getMenu().add("About this app").setOnMenuItemClickListener(item -> {
            new AlertDialog.Builder(this).setTitle("GREEN PLUG EV")
                .setMessage("Cinematic EV charging discovery and station booking. This Android app connects to your configured GREEN PLUG EV server; account roles, bookings and database remain on the server. Demo services may be enabled by the server administrator.")
                .setPositiveButton("OK", null).show(); return true;
        });
        menu.show();
    }

    private void showServerDialog(boolean firstRun) {
        final EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(14);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        input.setHint("https://your-server.example/app/");
        String current = appUrl.isEmpty() ? EMULATOR_DEFAULT : appUrl;
        input.setText(current);
        input.setSelection(input.getText().length());

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(22), dp(10), dp(22), 0);
        TextView message = new TextView(this);
        message.setText("Enter the address of your GREEN PLUG EV backend. This app loads the web interface from that server so sign-in, bookings and PostgreSQL stay connected.\n\nAndroid emulator: http://10.0.2.2:8080/app/\nPhysical phone on the same Wi-Fi: use your computer's IPv4 address, for example http://192.168.1.20:8080/app/\nHosted server: use its HTTPS URL.");
        message.setTextColor(Color.rgb(62, 78, 68));
        message.setTextSize(13);
        content.addView(message);
        content.addView(input, new LinearLayout.LayoutParams(-1, dp(52)));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(firstRun ? "Connect your app" : "Change server")
            .setView(content)
            .setNegativeButton(firstRun ? "Exit" : "Cancel", (d, w) -> { if (firstRun && appUrl.isEmpty()) finish(); })
            .setPositiveButton("Connect", null)
            .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String normalized;
            try { normalized = normalizeAppUrl(input.getText().toString()); }
            catch (IllegalArgumentException ex) {
                input.setError(ex.getMessage());
                return;
            }
            appUrl = normalized;
            prefs.edit().putString(KEY_SERVER_URL, appUrl).apply();
            dialog.dismiss();
            loadApp();
        }));
        dialog.show();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }

    private String normalizeAppUrl(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.isEmpty()) throw new IllegalArgumentException("Enter your backend URL.");
        Uri u = Uri.parse(value);
        String scheme = u.getScheme();
        if (scheme == null || u.getHost() == null || !(scheme.equalsIgnoreCase("http") || scheme.equalsIgnoreCase("https")))
            throw new IllegalArgumentException("Use a valid http:// or https:// URL.");
        if (u.getUserInfo() != null) throw new IllegalArgumentException("Do not put usernames or passwords in the URL.");
        String path = u.getPath() == null ? "" : u.getPath();
        if (path.isEmpty() || path.equals("/")) path = "/app/";
        else if (path.equalsIgnoreCase("/app")) path = "/app/";
        else if (!path.toLowerCase(Locale.ROOT).startsWith("/app/"))
            throw new IllegalArgumentException("Use the app path, for example https://your-server/app/.");
        return u.buildUpon().encodedPath(path).clearQuery().fragment(null).build().toString();
    }

    private void loadApp() {
        if (appUrl == null || appUrl.isEmpty()) { showServerDialog(true); return; }
        connectivityHint.setVisibility(View.VISIBLE);
        connectivityHint.setText("Connecting to GREEN PLUG EV…");
        webView.loadUrl(appUrl);
    }

    private boolean isInternalUrl(Uri uri) {
        if (uri == null || appUrl == null || appUrl.isEmpty()) return false;
        Uri base = Uri.parse(appUrl);
        return uri.getScheme() != null && uri.getScheme().equalsIgnoreCase(base.getScheme())
            && uri.getHost() != null && uri.getHost().equalsIgnoreCase(base.getHost())
            && effectivePort(uri) == effectivePort(base);
    }

    private boolean isSameHost(String origin) {
        try { return isInternalUrl(Uri.parse(origin)); } catch (Exception e) { return false; }
    }

    private int effectivePort(Uri u) {
        if (u.getPort() != -1) return u.getPort();
        return "https".equalsIgnoreCase(u.getScheme()) ? 443 : 80;
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException e) { Toast.makeText(this, "No app can open this link.", Toast.LENGTH_SHORT).show(); }
    }

    private void showConnectionError() {
        if (errorDialogShowing || isFinishing()) return;
        errorDialogShowing = true;
        progress.setVisibility(View.GONE);
        connectivityHint.setVisibility(View.VISIBLE);
        connectivityHint.setText("Cannot reach the server. Check that it is running and the URL is correct.");
        new AlertDialog.Builder(this)
            .setTitle("Server unavailable")
            .setMessage("GREEN PLUG EV connects to the backend you configured. For local testing, keep the Node server running and make sure this phone and computer can reach one another.\n\nCurrent URL:\n" + appUrl)
            .setPositiveButton("Retry", (d, w) -> loadApp())
            .setNeutralButton("Change URL", (d, w) -> showServerDialog(false))
            .setNegativeButton("Close", null)
            .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST && pendingGeoCallback != null) {
            boolean granted = false;
            for (int result : grantResults) if (result == PackageManager.PERMISSION_GRANTED) granted = true;
            pendingGeoCallback.invoke(pendingGeoOrigin, granted && isSameHost(pendingGeoOrigin), false);
            pendingGeoCallback = null;
            pendingGeoOrigin = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else new AlertDialog.Builder(this).setMessage("Exit GREEN PLUG EV?")
            .setNegativeButton("Stay", null).setPositiveButton("Exit", (d, w) -> finish()).show();
    }

    @Override
    protected void onPause() {
        if (webView != null) webView.onPause();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    private int systemBarHeight(String resourceName) {
        int id = getResources().getIdentifier(resourceName, "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    private int dp(int value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
}
