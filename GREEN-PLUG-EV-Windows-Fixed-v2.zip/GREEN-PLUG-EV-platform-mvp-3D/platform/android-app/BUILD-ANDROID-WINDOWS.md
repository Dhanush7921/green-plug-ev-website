# GREEN PLUG EV — Android APK

This folder is a native Android WebView client for the existing GREEN PLUG EV platform. It preserves the platform's real hosted frontend (including the 3D scene and all three workspaces) and its same-origin API/session integration by loading `/app/` from the configured Node server. PostgreSQL and the Node API remain on the server; they are not embedded in Android.

## Important architecture note

The APK is an installable Android shell, not an offline copy of the backend. The frontend and API are served from the URL entered when the app first opens. This avoids duplicating authentication, cookies, booking logic or database code in the Android app.

- Android emulator → use `http://10.0.2.2:8080/app/` when the Node server runs on the development computer.
- Physical Android phone on the same Wi-Fi → use `http://PC-LAN-IP:8080/app/`, with the Node server configured to listen on `0.0.0.0`. The PC firewall may need to allow TCP 8080 on the private network.
- Hosted environment → enter the app's `https://` URL. A release build refuses cleartext HTTP; the debug build permits HTTP for local development only.

For local phone testing, set `HOST=0.0.0.0`, `PORT=8080`, and `APP_ORIGIN=http://YOUR-PC-LAN-IP:8080` in `platform/.env` (replace the IP). Keep the phone and PC on the same trusted Wi-Fi. Do not expose this demo server to the public internet. Restart the server after changing `.env`.

## Build a debug APK on Windows

1. Install Android Studio.
2. In Android Studio → **More Actions → SDK Manager**, install **Android SDK Platform 35** and **Android SDK Build-Tools 35.0.0** (or a compatible 35.x version).
3. Ensure Android Studio's bundled JDK 17+ is installed.
4. Open PowerShell in this `android-app` folder.
5. Run:

   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\build-apk.ps1
   ```

   The script downloads the official Gradle 8.10.2 distribution if it is not already cached, then runs `assembleDebug`. Internet access is needed to download Gradle and Android Gradle Plugin dependencies on the first build.
6. The APK is written to `dist\GREEN-PLUG-EV-debug.apk`.
7. Transfer the APK to an Android device and open it to install. Allow installation from that source when Android prompts you.
8. On first launch, enter the server URL. The overflow menu lets you change it later.

If PowerShell cannot find the SDK, install the components in SDK Manager and verify that the SDK location is `%LOCALAPPDATA%\Android\Sdk` or set `ANDROID_SDK_ROOT` to the actual SDK folder.

## Before using on a phone

1. Start PostgreSQL and the Node platform server on the development PC.
2. Use `ipconfig` on Windows to find the PC's IPv4 address on the Wi-Fi adapter, for example `192.168.1.20`.
3. Open `http://PC-LAN-IP:8080/app/` on the phone's browser first. This confirms the phone can reach the server.
4. Enter the same URL in the app. Do not enter `localhost` on a physical phone; that points to the phone itself.
5. Browser geolocation generally requires a secure context. Location may not work over a plain HTTP LAN address; use manual search during local testing or an HTTPS hosted URL.

## Release/signing

`assembleDebug` produces a debug-signed APK suitable for personal testing. A public release requires a private signing keystore, HTTPS server, production configuration and security review. The current server settings deliberately use demo/test integrations unless explicitly reconfigured. Never embed database passwords, payment secrets or other backend secrets in the APK.
