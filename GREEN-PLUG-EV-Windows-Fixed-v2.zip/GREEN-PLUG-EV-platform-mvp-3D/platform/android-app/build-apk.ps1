$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$GradleVersion = '8.10.2'

Write-Host 'GREEN PLUG EV Android debug APK builder' -ForegroundColor Green

# Locate Android SDK installed by Android Studio.
$Sdk = $env:ANDROID_SDK_ROOT
if (-not $Sdk) { $Sdk = $env:ANDROID_HOME }
if (-not $Sdk -and $env:LOCALAPPDATA) {
    $candidate = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
    if (Test-Path $candidate) { $Sdk = $candidate }
}
if (-not $Sdk -or -not (Test-Path (Join-Path $Sdk 'platforms\android-35\android.jar'))) {
    Write-Host ''
    Write-Host 'Android SDK platform 35 was not found.' -ForegroundColor Yellow
    Write-Host 'Install Android Studio, open SDK Manager, and install:'
    Write-Host '  - Android SDK Platform 35'
    Write-Host '  - Android SDK Build-Tools 35.0.0 (or a compatible 35.x version)'
    Write-Host 'Then rerun this script. Common SDK path: %LOCALAPPDATA%\Android\Sdk'
    exit 2
}
$env:ANDROID_SDK_ROOT = $Sdk
$env:ANDROID_HOME = $Sdk
Write-Host "Android SDK: $Sdk"

# Android Gradle Plugin 8.8.2 requires JDK 17 or newer. Prefer Android Studio's bundled JBR.
if (-not $env:JAVA_HOME -or -not (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    $javaCandidates = @(
        (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'),
        (Join-Path $env:LOCALAPPDATA 'Programs\Android Studio\jbr')
    )
    foreach ($candidate in $javaCandidates) {
        if ($candidate -and (Test-Path (Join-Path $candidate 'bin\java.exe'))) { $env:JAVA_HOME = $candidate; break }
    }
}
if (-not $env:JAVA_HOME -or -not (Test-Path (Join-Path $env:JAVA_HOME 'bin\java.exe'))) {
    Write-Host 'JDK 17+ was not found. Install Android Studio or set JAVA_HOME to a JDK 17+ directory.' -ForegroundColor Yellow
    exit 3
}
Write-Host "Java: $env:JAVA_HOME"

# Download a standalone Gradle distribution when one is not already cached; no Gradle wrapper JAR is needed.
$CacheRoot = Join-Path $env:LOCALAPPDATA 'GreenPlugEV\gradle'
$GradleHome = Join-Path $CacheRoot "gradle-$GradleVersion"
$GradleExe = Join-Path $GradleHome 'bin\gradle.bat'
if (-not (Test-Path $GradleExe)) {
    New-Item -ItemType Directory -Force -Path $CacheRoot | Out-Null
    $ZipPath = Join-Path $env:TEMP "gradle-$GradleVersion-bin.zip"
    $ExtractPath = Join-Path $env:TEMP "greenplug-gradle-$GradleVersion"
    if (-not (Test-Path $ZipPath)) {
        $Url = "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip"
        Write-Host "Downloading Gradle $GradleVersion from the official distribution site..."
        Invoke-WebRequest -Uri $Url -OutFile $ZipPath
    }
    if (Test-Path $ExtractPath) { Remove-Item -LiteralPath $ExtractPath -Recurse -Force }
    Expand-Archive -LiteralPath $ZipPath -DestinationPath $ExtractPath -Force
    $ExtractedGradle = Join-Path $ExtractPath "gradle-$GradleVersion"
    if (-not (Test-Path (Join-Path $ExtractedGradle 'bin\gradle.bat'))) { throw 'Gradle archive did not contain the expected executable.' }
    if (Test-Path $GradleHome) { Remove-Item -LiteralPath $GradleHome -Recurse -Force }
    Move-Item -LiteralPath $ExtractedGradle -Destination $GradleHome
}

Push-Location $ProjectDir
try {
    & $GradleExe --no-daemon --stacktrace assembleDebug
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed with exit code $LASTEXITCODE" }
    $BuiltApk = Join-Path $ProjectDir 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path $BuiltApk)) { throw 'Gradle reported success but the APK file was not found.' }
    $OutDir = Join-Path $ProjectDir 'dist'
    New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
    $OutApk = Join-Path $OutDir 'GREEN-PLUG-EV-debug.apk'
    Copy-Item -LiteralPath $BuiltApk -Destination $OutApk -Force
    Write-Host ''
    Write-Host 'APK BUILD SUCCESSFUL' -ForegroundColor Green
    Write-Host "APK: $OutApk" -ForegroundColor Green
    Write-Host 'This is a debug-install APK. It connects to the server URL entered on first launch.'
} finally {
    Pop-Location
}
