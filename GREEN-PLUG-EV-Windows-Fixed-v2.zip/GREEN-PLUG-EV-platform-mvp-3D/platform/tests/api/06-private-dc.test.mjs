// Home (AC) charging is the public offer. Private DC fast chargers are admin-managed and stay hidden from every
// public endpoint until the owner's deal is accepted AND an admin publishes the station.
import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { admin, book, Client, db, futureSlot, login, newDriver, pay } from '../helpers.mjs';

let adm, drv, stationId, connectorId;
const NAME = `Private DC Test ${Date.now().toString(36)}`;
before(async () => {
  adm = await admin();
  drv = await newDriver('DC Driver');
});
after(() => db.end());

const publicIds = async () => (await new Client().get('/api/stations')).body.stations.map((s) => s.id);
const create = (c) =>
  c.post('/api/admin/dc-stations', {
    owner: { name: 'Harbour Logistics (DC owner)', email: 'fleet@harbour.example', phone: '+91 90000 77777', address: 'Port Road, Visakhapatnam' },
    station: { name: NAME, address: 'Gate 3, Port Road', area: 'Port Area', city: 'Visakhapatnam', latitude: 17.69, longitude: 83.28, accessType: 'PRIVATE' },
    connector: { label: 'DC-60', standard: 'CCS2', maxPowerKw: 60, pricePerKwh: 21 },
    note: 'Owner reviewing the 15% + 15% proposal',
  });

describe('customer-facing DC removal', () => {
  it('public APIs expose AC connectors only (no DC from regular partner stations)', async () => {
    const r = await new Client().get('/api/stations');
    assert.ok(r.body.stations.length > 0);
    for (const s of r.body.stations) assert.ok(s.connectors.every((c) => c.currentType === 'AC'), `${s.name} exposes DC`);
    assert.equal((await new Client().get('/api/stations?current=DC')).body.count, 0);
    // seeded stations with DC connectors keep them in the database (data preserved) but they are not bookable
    const [dc] = await db`SELECT c.id, c.station_id FROM connectors c JOIN stations s ON s.id = c.station_id WHERE c.current_type = 'DC' AND s.dc_deal_status IS NULL AND s.listing_status = 'APPROVED' LIMIT 1`;
    assert.ok(dc, 'seed data still has DC connectors');
    const est = await new Client().post(`/api/stations/${dc.stationId}/estimate`, { connectorId: dc.id, plannedKwh: 10 });
    assert.equal(est.status, 404);
    const b = await book(drv, dc.stationId, dc.id, futureSlot(2, '10:00'));
    assert.equal(b.status, 404);
  });
});

describe('admin-only private DC workflow', () => {
  it('only admins can list or create private DC stations', async () => {
    assert.equal((await new Client().get('/api/admin/dc-stations')).status, 401);
    assert.equal((await drv.get('/api/admin/dc-stations')).status, 403);
    const partner = await login('partner@greenplug.test', 'PartnerDemo2026');
    assert.equal((await create(partner)).status, 403);
    const r = await create(adm);
    assert.equal(r.status, 201, JSON.stringify(r.body));
    stationId = r.body.id;
    const list = await adm.get('/api/admin/dc-stations');
    const s = list.body.stations.find((x) => x.id === stationId);
    assert.equal(s.dcDealStatus, 'PENDING');
    connectorId = s.connectors[0].id;
  });

  it('stays hidden while PENDING and DEAL_ACCEPTED; cannot skip to PUBLISHED', async () => {
    assert.ok(!(await publicIds()).includes(stationId));
    assert.equal((await new Client().get(`/api/stations/${stationId}`)).status, 404);
    assert.equal((await new Client().get(`/api/stations/${stationId}/availability`)).status, 404);
    assert.equal((await book(drv, stationId, connectorId, futureSlot(2, '11:00'))).status, 404);
    const skip = await adm.post(`/api/admin/dc-stations/${stationId}/status`, { status: 'PUBLISHED' });
    assert.equal(skip.status, 409);
    const general = await adm.post(`/api/admin/stations/${stationId}/decision`, { decision: 'APPROVE' });
    assert.equal(general.status, 409, 'generic listing approval cannot bypass the deal workflow');
    assert.equal((await adm.post(`/api/admin/dc-stations/${stationId}/status`, { status: 'DEAL_ACCEPTED', note: 'Signed 15% + 15%' })).status, 200);
    assert.ok(!(await publicIds()).includes(stationId), 'deal accepted is still not published');
    // database guard: a DC deal station cannot be listed unless PUBLISHED
    await assert.rejects(db`UPDATE stations SET listing_status = 'APPROVED' WHERE id = ${stationId}`);
  });

  it('PUBLISHED makes exactly that station public and bookable; unpublish is blocked by active bookings', async () => {
    assert.equal((await adm.post(`/api/admin/dc-stations/${stationId}/status`, { status: 'PUBLISHED' })).status, 200);
    assert.ok((await publicIds()).includes(stationId));
    const det = await new Client().get(`/api/stations/${stationId}`);
    assert.equal(det.status, 200);
    assert.equal(det.body.station.connectors[0].currentType, 'DC');
    assert.equal(det.body.station.contact, null, 'owner contact is never public');
    const b = await book(drv, stationId, connectorId, futureSlot(2, '12:00'));
    assert.equal(b.status, 201, JSON.stringify(b.body));
    const paid = await pay(drv, b.body.paymentOrder.id);
    assert.equal(paid.body.bookingStatus, 'CONFIRMED', 'payment confirms a booking at an admin-managed station');
    const un = await adm.post(`/api/admin/dc-stations/${stationId}/status`, { status: 'DEAL_ACCEPTED' });
    assert.equal(un.status, 409);
    await drv.post(`/api/bookings/${b.body.booking.id}/cancel`, {});
    assert.equal((await adm.post(`/api/admin/dc-stations/${stationId}/status`, { status: 'DEAL_ACCEPTED' })).status, 200);
    assert.ok(!(await publicIds()).includes(stationId), 'unpublished again');
  });
});
