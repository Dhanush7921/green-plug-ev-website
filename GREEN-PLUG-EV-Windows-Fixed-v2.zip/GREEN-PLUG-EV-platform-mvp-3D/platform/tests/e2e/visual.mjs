// Visual QA run: captures the cinematic intro and every workspace with real-time 3D enabled, checks for console
// errors, failed assets, overflow, blocked interaction, theme persistence, mode-switch permissions and the reduced-
// motion path, then writes screenshots + VISUAL-QA.md to tests/e2e/artifacts/visual/.
//
//   node tests/e2e/visual.mjs                         builds, resets gpev_visual, starts its own server
//   E2E_BASE_URL=http://127.0.0.1:8080 node tests/e2e/visual.mjs
//
// Headless Chromium renders WebGL with SwiftShader (software), so scenes take longer to appear than on a GPU; the
// intro is frozen at fixed seconds with a QA hook to make frames deterministic.
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const OUT = path.join(root, 'tests/e2e/artifacts/visual');
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(OUT, { recursive: true });

const PORT = process.env.E2E_PORT || '8093';
const OWN = !process.env.E2E_BASE_URL;
const BASE = process.env.E2E_BASE_URL || `http://127.0.0.1:${PORT}`;
const env = { ...process.env, DATABASE_URL: process.env.VISUAL_DATABASE_URL || 'postgres://postgres:devpassword@127.0.0.1:5433/gpev_visual', PORT, LOG_REQUESTS: '0', RATE_LIMIT_FACTOR: '20', DEMO_MODE: 'true', PAYMENT_PROVIDER: 'test', APP_ORIGIN: BASE, STORAGE_DIR: path.join(root, '.test-storage') };
let server = null;
if (OWN) {
  for (const args of [['scripts/build.mjs', 'all', '--prod'], ['dist/cli.mjs', 'reset']]) {
    const r = spawnSync('node', args, { cwd: root, env, stdio: 'inherit' });
    if (r.status !== 0) process.exit(r.status ?? 1);
  }
  server = spawn('node', ['dist/server.mjs'], { cwd: root, env, stdio: ['ignore', 'ignore', 'inherit'] });
  for (let i = 0; i < 60; i++) {
    try {
      if ((await fetch(`${BASE}/api/health`)).ok) break;
    } catch {
      /* starting */
    }
    await new Promise((r) => setTimeout(r, 200));
  }
}

const checks = [];
const shots = [];
const metrics = {};
const consoleErrors = [];
const failedAssets = [];
const IGNORE = /GroupMarkerNotSet|swiftshader|GPU stall|KHR_parallel_shader_compile|status of 40[13]/i;
const check = (name, ok, detail = '') => {
  checks.push({ name, ok: !!ok, detail });
  console.log(`  ${ok ? '✓' : '✗'} ${name}${detail ? ` — ${detail}` : ''}`);
};
async function shot(page, name, title, full = false) {
  await page.waitForTimeout(250);
  const f = `${String(shots.length + 1).padStart(2, '0')}-${name}.png`;
  await page.screenshot({ path: path.join(OUT, f), fullPage: full, timeout: 120000 });
  shots.push({ file: f, title });
  return f;
}
const browser = await chromium.launch({ args: ['--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
async function ctx(opts = {}) {
  const { seen = true, ...rest } = opts;
  const c = await browser.newContext({ viewport: { width: 1440, height: 900 }, baseURL: BASE, ...rest });
  c.setDefaultTimeout(120000); // software WebGL frames are slow
  await c.addInitScript(
    ([seenIntro]) => {
      try {
        if (seenIntro) localStorage.setItem('gpev-app-intro-seen', '1');
        localStorage.setItem('gpev-effects', 'off');
      } catch {
        /* about:blank */
      }
    },
    [seen],
  );
  c.on('page', (p) => {
    p.on('pageerror', (e) => consoleErrors.push(`${p.url()} ${e.message}`));
    p.on('console', (m) => m.type() === 'error' && !IGNORE.test(m.text()) && consoleErrors.push(`${p.url()} ${m.text()}`));
    p.on('response', (r) => r.status() >= 400 && !/\/api\//.test(r.url()) && failedAssets.push(`${r.status()} ${r.url()}`));
    // ERR_ABORTED = request cancelled by a navigation, not a broken asset
    p.on('requestfailed', (r) => !/\/api\//.test(r.url()) && !/ERR_ABORTED/.test(r.failure()?.errorText || '') && failedAssets.push(`failed ${r.url()} ${r.failure()?.errorText}`));
  });
  return c;
}
async function login(p, email, password) {
  await p.goto('/app/signin');
  await p.getByLabel('Email').fill(email);
  await p.getByLabel('Password').fill(password);
  await p.getByRole('button', { name: 'Sign in', exact: true }).click();
  await p.waitForURL((u) => !u.pathname.endsWith('/signin'));
}
async function stageReady(p, mode, timeout = 120000) {
  const t0 = Date.now();
  await p.locator(`[data-testid=stage-${mode}][data-stage-state=ready]`).waitFor({ timeout });
  await p.waitForTimeout(1200); // canvas fade-in
  return Date.now() - t0;
}
const overflow = (p) => p.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);

console.log(`\nGREEN PLUG EV — visual QA against ${BASE}\n`);
try {
  // ------------------------------------------------------------------ 1. cinematic intro (first visit)
  {
    const c = await ctx({ seen: false, viewport: { width: 1440, height: 810 } });
    const p = await c.newPage();
    const t0 = Date.now();
    await p.goto('/app/?introwait=300');
    await p.getByTestId('intro').waitFor();
    await p.locator('[data-testid=intro][data-phase=playing]').waitFor({ timeout: 150000 });
    metrics.introReadyMs = Date.now() - t0;
    metrics.intro = await p.evaluate(() => window.__gpevIntro?.diagnostics());
    // wheels: all four re-pivoted at their hubs and rolling with the drive-in (angle changes between two frames)
    await p.evaluate(() => window.__gpevIntro?.seekIntro(0.8));
    const w1 = await p.evaluate(() => window.__gpevIntro?.diagnostics().wheelAngles);
    await p.evaluate(() => window.__gpevIntro?.seekIntro(1.1));
    const w2 = await p.evaluate(() => window.__gpevIntro?.diagnostics().wheelAngles);
    check('Intro: all four car wheels spin about their hubs while the car drives in', metrics.intro?.spinningWheels === 4 && w1?.length === 4 && w1.every((a, i) => Math.abs(a - w2[i]) > 0.01), `wheels ${metrics.intro?.spinningWheels}; angles ${JSON.stringify(w1)} → ${JSON.stringify(w2)}`);
    for (const [t, name, title] of [
      [0.6, 'intro-1-arrival', 'Intro · the EV arrives nose-first down the lit lane, headlights through the dusk'],
      [2.3, 'intro-2-parked', 'Intro · parked at the bay, inlet door opening'],
      [3.7, 'intro-3-plug', 'Intro · close-up: the charging handle travels from the holster to the inlet'],
      [5.05, 'intro-4-connect', 'Intro · connection flash, energy pulse in the cable, station lights respond'],
      [6.6, 'intro-5-reveal', 'Intro · logo reveal over the charging bay'],
    ]) {
      await p.evaluate((s) => window.__gpevIntro?.seekIntro(s), t);
      await p.waitForTimeout(t > 6 ? 3200 : 1600); // the logo wipe is a 1.1 s CSS transition
      await shot(p, name, title);
    }
    const skipVisible = await p.getByTestId('skip-intro').isVisible();
    await p.getByTestId('skip-intro').click();
    await p.getByTestId('intro').waitFor({ state: 'detached', timeout: 5000 });
    check('Intro: plays on first visit with a visible Skip control', skipVisible, `scene ready after ${(metrics.introReadyMs / 1000).toFixed(1)} s on software WebGL; realistic car: ${metrics.intro?.realisticCar}`);
    await p.waitForTimeout(800);
    await shot(p, 'intro-6-handoff', 'Intro skipped → dashboard (hand-off)');
    await p.reload();
    await p.waitForTimeout(1500);
    check('Intro: does not replay on the next visit', (await p.getByTestId('intro').count()) === 0);
    await p.goto('/app/signin');
    check('Intro: never on deep links (sign-in)', (await p.getByTestId('intro').count()) === 0);
    await c.close();
  }

  // ------------------------------------------------------------------ 2/3. driver dashboard light + dark
  const dc = await ctx();
  const d = await dc.newPage();
  await login(d, 'asha@greenplug.test', 'DriverDemo2026');
  await d.goto('/app/');
  metrics.heroReadyMs = await stageReady(d, 'hero');
  metrics.hero = await d.evaluate(() => window.__gpevStages?.hero?.diagnostics());
  await shot(d, 'driver-dashboard-light', 'EV Driver dashboard · light theme (real-time 3D hero, search, map, cards)');
  check('Driver hero: WebGL scene rendered', metrics.hero?.calls > 0, `${metrics.hero?.calls} draw calls, ${Math.round((metrics.hero?.triangles || 0) / 1000)}k triangles, dpr ${metrics.hero?.dpr}, quality ${metrics.hero?.quality}`);
  check('Driver dashboard: no horizontal overflow (1440)', (await overflow(d)) <= 0);
  await d.locator('.topbar .theme-toggle').click();
  await d.waitForFunction(() => document.documentElement.dataset.theme === 'dark');
  await d.waitForTimeout(1500);
  await shot(d, 'driver-dashboard-dark', 'EV Driver dashboard · dark theme (scene relit, not just inverted)');
  await d.reload();
  await stageReady(d, 'hero');
  check('Theme: dark persists across reload and the 3D scene follows it', (await d.evaluate(() => document.documentElement.dataset.theme)) === 'dark');
  await d.locator('.topbar .theme-toggle').click();
  await d.waitForFunction(() => document.documentElement.dataset.theme === 'light');
  // interaction while the scene animates
  const t0 = Date.now();
  await d.getByTestId('search-input').fill('MVP');
  await d.getByTestId('station-card').first().waitFor();
  check('Animation never blocks input (search typed while the hero renders)', Date.now() - t0 < 8000, `${Date.now() - t0} ms`);
  await d.getByTestId('search-input').fill('');
  await d.waitForFunction(() => document.querySelectorAll('[data-testid=station-card]').length > 5);
  // off-screen pause
  await d.evaluate(() => window.scrollTo(0, document.body.scrollHeight));
  const paused = await d
    .waitForFunction(() => window.__gpevStages?.hero?.diagnostics().running === false, null, { timeout: 15000 })
    .then(() => true)
    .catch(() => false);
  check('3D loop pauses when the scene is scrolled off-screen', paused);
  await d.evaluate(() => window.scrollTo(0, 0));

  // ------------------------------------------------------------------ 4. search + detail panel
  await d.getByTestId('filters-toggle').click();
  await d.getByTestId('filters').locator('.chip-btn', { hasText: 'Type 2' }).click();
  await d.locator('.dm-pin').first().waitFor();
  await d.locator('.dm-pin').nth(2).click({ force: true }); // pins can overlap in the Visakhapatnam cluster
  await d.getByTestId('station-preview').waitFor();
  await d.getByTestId('station-preview').scrollIntoViewIfNeeded();
  await shot(d, 'station-search-preview', 'Station discovery · Type 2 AC filter, animated markers, map selection opens the preview panel');
  await d.getByTestId('station-preview').getByRole('link', { name: /View & book/ }).click();
  await d.getByTestId('station-title').waitFor();
  metrics.stationReadyMs = await stageReady(d, 'station');
  await shot(d, 'station-detail', 'Station detail · 3D charging-bay hero, connectors, compatibility and booking panel');

  // ------------------------------------------------------------------ 5. booking workflow
  const panel = d.getByTestId('booking-panel');
  await panel.scrollIntoViewIfNeeded();
  await d.locator('.date-chips .chip-btn').nth(1).click();
  await d.locator('[data-testid=slot-grid] .slot:not([disabled])').first().waitFor();
  await d.locator('[data-testid=slot-grid] .slot:not([disabled])').nth(4).click();
  await d.getByTestId('estimate').waitFor();
  await d.getByTestId('energy-meter').waitFor();
  await panel.screenshot({ path: path.join(OUT, `${String(shots.length + 1).padStart(2, '0')}-booking-panel.png`) });
  shots.push({ file: `${String(shots.length + 1).padStart(2, '0')}-booking-panel.png`, title: 'Booking · slot grid, energy meter and transparent price breakdown' });
  await d.getByTestId('book-button').click();
  await d.getByTestId('checkout').waitFor();
  await shot(d, 'booking-checkout', 'Booking · TEST-mode checkout (clearly labelled, no real money)');
  await d.getByTestId('pay-success').click();
  await d.waitForURL(/\/app\/bookings\//);
  await d.waitForFunction(() => document.querySelector('[data-testid=booking-status]')?.textContent === 'Confirmed');
  await shot(d, 'booking-confirmed', 'Booking · confirmed by verified webhook, charging visual, lifecycle and price breakdown');
  check('Booking workflow still completes with the visual layer', true, 'confirmed');

  // trips (route animation)
  await d.goto('/app/trips');
  await d.getByRole('textbox', { name: 'From' }).fill('Visakhapatnam');
  await d.locator('.suggest button').first().click();
  await d.getByRole('textbox', { name: 'To', exact: true }).fill('Vijayawada');
  await d.locator('.suggest button').first().click();
  await d.getByTestId('plan-trip').click();
  await d.getByTestId('route-progress').waitFor();
  await d.waitForTimeout(2600);
  await d.getByTestId('route-progress').scrollIntoViewIfNeeded();
  await shot(d, 'trip-route', 'Trip planner · animated route progress with charging stops');
  await d.goto('/app/garage');
  await d.getByTestId('vehicle-row').first().waitFor();
  await shot(d, 'garage', 'Saved vehicles · three-quarter EV cards');

  // ------------------------------------------------------------------ mode switch: permissions + transition
  await d.goto('/app/');
  // slow every animation down so the software renderer can photograph the ~0.8 s transition mid-way
  const cdp = await dc.newCDPSession(d);
  await cdp.send('Animation.enable');
  await cdp.send('Animation.setPlaybackRate', { playbackRate: 0.12 });
  await d.locator('.topbar .switch-mode-btn[data-mode=partner]').click();
  await d.getByTestId('mode-transition').waitFor({ timeout: 15000 });
  await d.waitForTimeout(2200);
  await shot(d, 'mode-switch-transition', 'SWITCH MODE · energy-sweep transition (plays only after the server answers; slowed for the photo)');
  await cdp.send('Animation.setPlaybackRate', { playbackRate: 1 });
  await d.waitForURL(/\/app\/partner\/apply/);
  const deny = await d.request.get('/api/partner/stations');
  check('Mode switch: unapproved partner still gets onboarding; partner API 403', deny.status() === 403);
  const adm = await d.request.post('/api/me/workspace', { data: { mode: 'admin' }, headers: { 'x-gpev-csrf': '1' } });
  check('Mode switch: admin denied for a driver', (await adm.json()).granted === 'denied');

  // ------------------------------------------------------------------ 6. partner dashboard
  const pc = await ctx();
  const p = await pc.newPage();
  await login(p, 'partner@greenplug.test', 'PartnerDemo2026');
  // make some revenue for the charts: the driver books and the partner completes
  await p.goto('/app/partner');
  metrics.partnerReadyMs = await stageReady(p, 'partner');
  await shot(p, 'partner-dashboard', 'Station Partner dashboard · cinematic header, stats, earnings chart, revenue split');
  await p.goto('/app/partner/stations');
  await p.getByTestId('partner-station').first().waitFor();
  await shot(p, 'partner-stations', 'Station Partner · station cards with connector-status indicators');
  await p.goto('/app/partner/bookings');
  await p.waitForTimeout(800);
  await shot(p, 'partner-calendar', 'Station Partner · booking calendar');
  check('Partner dashboard: no horizontal overflow', (await overflow(p)) <= 0);

  // ------------------------------------------------------------------ 7. admin dashboard
  const ac = await ctx();
  const a = await ac.newPage();
  await login(a, 'admin@greenplug.test', 'AdminDemo2026');
  await a.goto('/app/admin');
  metrics.adminReadyMs = await stageReady(a, 'admin');
  await shot(a, 'admin-dashboard', 'Admin overview · aerial 3D header, metrics, bookings-by-status and ledger charts');
  await a.locator('.topbar .theme-toggle').click();
  await a.waitForTimeout(1500);
  await shot(a, 'admin-dashboard-dark', 'Admin overview · dark theme');
  await a.locator('.topbar .theme-toggle').click();
  await a.goto('/app/admin/partners');
  await a.waitForTimeout(600);
  await shot(a, 'admin-approvals', 'Admin · partner approval queue');

  // ------------------------------------------------------------------ 8. mobile ~390 px
  const mc = await ctx({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true, deviceScaleFactor: 2 });
  const m = await mc.newPage();
  await login(m, 'ravi@greenplug.test', 'DriverDemo2026');
  await m.goto('/app/');
  metrics.mobileReadyMs = await stageReady(m, 'hero');
  metrics.mobile = await m.evaluate(() => window.__gpevStages?.hero?.diagnostics());
  await shot(m, 'mobile-dashboard', 'Mobile 390 px · driver hero (low-quality 3D profile), quick filters');
  check('Mobile: low-quality 3D profile and no overflow', metrics.mobile?.quality === 'low' && (await overflow(m)) <= 0, `dpr ${metrics.mobile?.dpr}`);
  await m.evaluate(() => window.scrollTo(0, 700));
  await m.waitForTimeout(600);
  await shot(m, 'mobile-map-list', 'Mobile 390 px · map, markers and station cards');
  await m.goto('/app/stations/' + (await m.evaluate(async () => (await (await fetch('/api/stations?q=RK')).json()).stations[0].id)));
  await stageReady(m, 'station');
  await shot(m, 'mobile-station', 'Mobile 390 px · station detail');
  // controls inside an intentionally scrollable strip (date chips, tables) are not clipped
  const clipped = await m.evaluate(() =>
    [...document.querySelectorAll('button, a.btn')]
      .filter((b) => {
        const r = b.getBoundingClientRect();
        if (!(r.width > 0 && (r.right > window.innerWidth + 1 || r.left < -1))) return false;
        for (let e = b.parentElement; e; e = e.parentElement) if (/(auto|scroll)/.test(getComputedStyle(e).overflowX)) return false;
        return true;
      })
      .map((b) => b.textContent?.trim().slice(0, 20)),
  );
  check('Mobile: no clipped controls', clipped.length === 0, clipped.length ? clipped.join(', ') : 'scrollable strips excluded');

  // ------------------------------------------------------------------ 9. reduced motion
  const rc = await ctx({ seen: false, reducedMotion: 'reduce' });
  const r = await rc.newPage();
  await r.goto('/app/');
  await r.waitForTimeout(600);
  check('Reduced motion: no intro on first visit', (await r.getByTestId('intro').count()) === 0);
  await stageReady(r, 'hero');
  const still = await r.evaluate(() => window.__gpevStages?.hero?.diagnostics().running === false);
  check('Reduced motion: 3D scene is a single still frame (no render loop)', still);
  const anims = await r.evaluate(() => document.getAnimations().filter((x) => x.playState === 'running' && (x.effect?.getTiming().iterations === Infinity)).length);
  check('Reduced motion: no infinite CSS animations running', anims === 0, `${anims} running`);
  await shot(r, 'reduced-motion', 'Reduced motion · still 3D frame, no intro, no looping effects');

  // ------------------------------------------------------------------ fallback: 3D off
  const fc = await ctx();
  await fc.addInitScript(() => {
    try {
      localStorage.setItem('gpev-3d', 'off');
    } catch {
      /* about:blank */
    }
  });
  const f = await fc.newPage();
  await f.goto('/app/');
  await f.locator('[data-testid=stage-hero][data-stage-state=fallback]').waitFor();
  await shot(f, 'illustration-fallback', 'Fallback · 3D off / no WebGL: original SVG illustration keeps the scene');
  check('No-WebGL / 3D-off fallback renders the illustration', true);

  check('No console errors', consoleErrors.length === 0, consoleErrors.slice(0, 3).join(' | '));
  check('No broken assets', failedAssets.length === 0, failedAssets.slice(0, 3).join(' | '));
} catch (e) {
  check('Visual run completed', false, e.message.split('\n')[0]);
  for (const c of browser.contexts()) for (const pg of c.pages()) await pg.screenshot({ path: path.join(OUT, `FAIL-${Date.now()}.png`) }).catch(() => {});
} finally {
  await browser.close();
  if (server) await new Promise((r) => (server.once('exit', r), server.kill('SIGTERM')));
  const ok = checks.filter((c) => c.ok).length;
  const s = (ms) => (ms ? `${(ms / 1000).toFixed(1)} s` : '—');
  const md = `# Visual QA — GREEN PLUG EV app

Run: ${new Date().toISOString()} · ${BASE} · headless Chromium with **software WebGL (SwiftShader)** — timings are far slower than on a real GPU.

## Checks: ${ok}/${checks.length} passed

| | Check | Detail |
|---|---|---|
${checks.map((c) => `| ${c.ok ? '✅' : '❌'} | ${c.name} | ${c.detail.replace(/\|/g, '/')} |`).join('\n')}

## Screenshots

| File | What it shows |
|---|---|
${shots.map((x) => `| [${x.file}](${x.file}) | ${x.title} |`).join('\n')}

## Scene metrics (software renderer)

| Scene | Time to first 3D frame | Notes |
|---|---|---|
| Intro | ${s(metrics.introReadyMs)} | car model: ${metrics.intro?.realisticCar ? 'licensed concept car (GLB)' : 'procedural fallback'} · ${metrics.intro?.calls ?? '—'} draw calls |
| Driver hero | ${s(metrics.heroReadyMs)} | ${metrics.hero?.calls ?? '—'} draw calls · ${Math.round((metrics.hero?.triangles || 0) / 1000)}k triangles · DPR ${metrics.hero?.dpr ?? '—'} |
| Station detail | ${s(metrics.stationReadyMs)} | |
| Partner header | ${s(metrics.partnerReadyMs)} | |
| Admin header | ${s(metrics.adminReadyMs)} | |
| Mobile hero | ${s(metrics.mobileReadyMs)} | quality ${metrics.mobile?.quality ?? '—'} · DPR ${metrics.mobile?.dpr ?? '—'} |

Console errors: ${consoleErrors.length}. Failed assets: ${failedAssets.length}.
${consoleErrors.length ? '\n```\n' + consoleErrors.slice(0, 20).join('\n') + '\n```\n' : ''}${failedAssets.length ? '\n```\n' + failedAssets.slice(0, 20).join('\n') + '\n```\n' : ''}
`;
  fs.writeFileSync(path.join(OUT, 'VISUAL-QA.md'), md);
  fs.writeFileSync(path.join(OUT, 'results.json'), JSON.stringify({ checks, shots, metrics, consoleErrors, failedAssets }, null, 2));
  console.log(`\n${ok}/${checks.length} visual checks passed · ${shots.length} screenshots in tests/e2e/artifacts/visual/\n`);
  process.exitCode = ok === checks.length && checks.length > 0 ? 0 : 1;
}
