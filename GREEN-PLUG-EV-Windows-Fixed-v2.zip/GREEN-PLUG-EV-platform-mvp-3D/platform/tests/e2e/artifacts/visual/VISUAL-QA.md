# Visual QA — GREEN PLUG EV app

Run: 2026-10-26T09:33:43.686Z · http://127.0.0.1:8093 · headless Chromium with **software WebGL (SwiftShader)** — timings are far slower than on a real GPU.

## Checks: 21/21 passed

| | Check | Detail |
|---|---|---|
| ✅ | Intro: all four car wheels spin about their hubs while the car drives in | wheels 4; angles [1.263,2.183,0.479,2.249] → [2.718,2.46,0.75,0.618] |
| ✅ | Intro: plays on first visit with a visible Skip control | scene ready after 33.3 s on software WebGL; realistic car: true |
| ✅ | Intro: does not replay on the next visit |  |
| ✅ | Intro: never on deep links (sign-in) |  |
| ✅ | Driver hero: WebGL scene rendered | 381 draw calls, 466k triangles, dpr 1, quality low |
| ✅ | Driver dashboard: no horizontal overflow (1440) |  |
| ✅ | Theme: dark persists across reload and the 3D scene follows it |  |
| ✅ | Animation never blocks input (search typed while the hero renders) | 4606 ms |
| ✅ | 3D loop pauses when the scene is scrolled off-screen |  |
| ✅ | Booking workflow still completes with the visual layer | confirmed |
| ✅ | Mode switch: unapproved partner still gets onboarding; partner API 403 |  |
| ✅ | Mode switch: admin denied for a driver |  |
| ✅ | Partner dashboard: no horizontal overflow |  |
| ✅ | Mobile: low-quality 3D profile and no overflow | dpr 1.25 |
| ✅ | Mobile: no clipped controls | scrollable strips excluded |
| ✅ | Reduced motion: no intro on first visit |  |
| ✅ | Reduced motion: 3D scene is a single still frame (no render loop) |  |
| ✅ | Reduced motion: no infinite CSS animations running | 0 running |
| ✅ | No-WebGL / 3D-off fallback renders the illustration |  |
| ✅ | No console errors |  |
| ✅ | No broken assets |  |

## Screenshots

| File | What it shows |
|---|---|
| [01-intro-1-arrival.png](01-intro-1-arrival.png) | Intro · the EV arrives nose-first down the lit lane, headlights through the dusk |
| [02-intro-2-parked.png](02-intro-2-parked.png) | Intro · parked at the bay, inlet door opening |
| [03-intro-3-plug.png](03-intro-3-plug.png) | Intro · close-up: the charging handle travels from the holster to the inlet |
| [04-intro-4-connect.png](04-intro-4-connect.png) | Intro · connection flash, energy pulse in the cable, station lights respond |
| [05-intro-5-reveal.png](05-intro-5-reveal.png) | Intro · logo reveal over the charging bay |
| [06-intro-6-handoff.png](06-intro-6-handoff.png) | Intro skipped → dashboard (hand-off) |
| [07-driver-dashboard-light.png](07-driver-dashboard-light.png) | EV Driver dashboard · light theme (real-time 3D hero, search, map, cards) |
| [08-driver-dashboard-dark.png](08-driver-dashboard-dark.png) | EV Driver dashboard · dark theme (scene relit, not just inverted) |
| [09-station-search-preview.png](09-station-search-preview.png) | Station discovery · Type 2 AC filter, animated markers, map selection opens the preview panel |
| [10-station-detail.png](10-station-detail.png) | Station detail · 3D charging-bay hero, connectors, compatibility and booking panel |
| [11-booking-panel.png](11-booking-panel.png) | Booking · slot grid, energy meter and transparent price breakdown |
| [12-booking-checkout.png](12-booking-checkout.png) | Booking · TEST-mode checkout (clearly labelled, no real money) |
| [13-booking-confirmed.png](13-booking-confirmed.png) | Booking · confirmed by verified webhook, charging visual, lifecycle and price breakdown |
| [14-trip-route.png](14-trip-route.png) | Trip planner · animated route progress with charging stops |
| [15-garage.png](15-garage.png) | Saved vehicles · three-quarter EV cards |
| [16-mode-switch-transition.png](16-mode-switch-transition.png) | SWITCH MODE · energy-sweep transition (plays only after the server answers; slowed for the photo) |
| [17-partner-dashboard.png](17-partner-dashboard.png) | Station Partner dashboard · cinematic header, stats, earnings chart, revenue split |
| [18-partner-stations.png](18-partner-stations.png) | Station Partner · station cards with connector-status indicators |
| [19-partner-calendar.png](19-partner-calendar.png) | Station Partner · booking calendar |
| [20-admin-dashboard.png](20-admin-dashboard.png) | Admin overview · aerial 3D header, metrics, bookings-by-status and ledger charts |
| [21-admin-dashboard-dark.png](21-admin-dashboard-dark.png) | Admin overview · dark theme |
| [22-admin-approvals.png](22-admin-approvals.png) | Admin · partner approval queue |
| [23-mobile-dashboard.png](23-mobile-dashboard.png) | Mobile 390 px · driver hero (low-quality 3D profile), quick filters |
| [24-mobile-map-list.png](24-mobile-map-list.png) | Mobile 390 px · map, markers and station cards |
| [25-mobile-station.png](25-mobile-station.png) | Mobile 390 px · station detail |
| [26-reduced-motion.png](26-reduced-motion.png) | Reduced motion · still 3D frame, no intro, no looping effects |
| [27-illustration-fallback.png](27-illustration-fallback.png) | Fallback · 3D off / no WebGL: original SVG illustration keeps the scene |

## Scene metrics (software renderer)

| Scene | Time to first 3D frame | Notes |
|---|---|---|
| Intro | 33.3 s | car model: licensed concept car (GLB) · 296 draw calls |
| Driver hero | 23.5 s | 381 draw calls · 466k triangles · DPR 1 |
| Station detail | 5.6 s | |
| Partner header | 21.5 s | |
| Admin header | 18.8 s | |
| Mobile hero | 22.6 s | quality low · DPR 1.25 |

Console errors: 0. Failed assets: 0.

